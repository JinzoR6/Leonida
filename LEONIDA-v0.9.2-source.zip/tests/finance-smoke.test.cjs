const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');

const elements = new Map();
function element(selector = '') {
  if (!elements.has(selector)) {
    const defaults = {
      '#money-current': '0',
      '#money-target': '0',
      '#payout-gross': '100000',
      '#payout-costs': '0',
      '#payout-share': '50',
      '#tracker-category': 'collectible'
    };
    elements.set(selector, {
      value: defaults[selector] || '',
      textContent: '',
      innerHTML: '',
      style: {},
      disabled: false,
      dataset: {},
      classList: { add() {}, remove() {}, toggle() {} },
      addEventListener() {}
    });
  }
  return elements.get(selector);
}

const document = {
  readyState: 'complete',
  querySelector: selector => element(selector),
  querySelectorAll: () => [],
  addEventListener() {}
};
const values = new Map();
const localStorage = {
  getItem: key => values.get(key) ?? null,
  setItem: (key, value) => values.set(key, value)
};
const window = { setTimeout, addEventListener() {} };

const context = {
  window, document, localStorage, console,
  crypto: { randomUUID: () => 'test-id' },
  structuredClone, Date, Math, Number, String, JSON,
  setTimeout, clearTimeout
};
vm.createContext(context);

const financePath = path.join(__dirname, '..', 'finance.js');
vm.runInContext(fs.readFileSync(financePath, 'utf8'), context);
const api = context.window.LEONIDA_FINANCE;

const tests = [
  ['calculates 50% of net payout', () => assert.equal(api.calculatePayout(100000, 10000, 50).take, 45000)],
  ['calculates 100% of net payout', () => assert.equal(api.calculatePayout(100000, 10000, 100).take, 90000)],
  ['rejects costs greater than gross take', () => assert.equal(api.calculatePayout(100, 101, 50).valid, false)],
  ['rejects share outside 0–100%', () => assert.equal(api.calculatePayout(100, 0, 150).valid, false)],
  ['rounds remaining runs up', () => assert.equal(api.calculateRunEstimate(100, 1000, 300), 3)],
  ['reports unknown run estimate without a prior payout', () => assert.equal(api.calculateRunEstimate(100, 1000, 0), null)],
  ['returns zero runs when target is already reached', () => assert.equal(api.calculateRunEstimate(1000, 500, 50), 0)]
];

let failures = 0;
for (const [name, run] of tests) {
  try {
    run();
    process.stdout.write(`PASS ${name}\n`);
  } catch (error) {
    failures++;
    process.stderr.write(`FAIL ${name}: ${error.message}\n`);
  }
}
if (failures) process.exitCode = 1;
else process.stdout.write(`\n${tests.length} finance smoke tests passed.\n`);

// Also run map framing, marker scaling, and catalogue-normalization smoke tests in CI.
require('./map-smoke.test.cjs');
