const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.join(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const helperStart = source.indexOf('const GTADB_TYPE_LABELS = {');
const renderStart = source.indexOf('function renderMapPins(', helperStart);
const parserStart = source.indexOf('function toCatalogueRecord(', renderStart);
const parserEnd = source.indexOf('async function importLocationsText(', parserStart);
assert.ok([helperStart, renderStart, parserStart, parserEnd].every(index => index >= 0), 'catalogue helper/parser functions are present');

const context = {
  GTADB_BOUNDS: { west: -16000, east: 4000, south: -8000, north: 12000 },
  GTADB_ATTRIBUTION: 'GTADB / Map GTA contributors · CC BY 4.0',
  GTADB_REVISION: 'test-revision',
  module: { exports: {} }
};
vm.runInNewContext(
  `${source.slice(helperStart, renderStart)}\n${source.slice(parserStart, parserEnd)}\nmodule.exports = { toCatalogueRecord, categoryFromTags, mapMarkerScale, mapMarkerVisualScale };`,
  context
);
const helpers = context.module.exports;
const row = (id, address, tags, coordinates = [0, 0], confidence = 'SUPPORTED', realWorldReference = 'Example reference, Miami, FL') => ({
  id,
  inGameAddress: address,
  inGameCoordinates: coordinates,
  realWorldReference,
  tags,
  confidence,
  evidence: {
    name: confidence === 'UNKNOWN' ? 'UNKNOWN' : 'KNOWN',
    placement: coordinates ? 'APPROXIMATE' : 'UNKNOWN',
    tagSignals: { levelTags: tags.filter(tag => /^l\\d+$/i.test(tag)), unconfirmed: tags.includes('unconfirmed'), demolished: tags.includes('demolished') }
  }
});
let passed = 0;
function pass(name, fn) { fn(); passed++; process.stdout.write(`PASS ${name}\n`); }

pass('splits venue, street, district and region', () => {
  const place = helpers.toCatalogueRecord(row('L25', 'Dominion Hotel, Shore Dr, Ocean Beach, Vice Beach', ['hotel', 'l1', 'enterable']), 0, true);
  assert.equal(place.name, 'Dominion Hotel');
  assert.equal(place.street, 'Shore Dr');
  assert.equal(place.district, 'Ocean Beach');
  assert.equal(place.region, 'Vice Beach');
  assert.equal(place.area, 'Ocean Beach · Vice Beach');
  assert.equal(place.type, 'Hotel');
  assert.deepEqual(Array.from(place.tags), ['Level 1', 'Enterable']);
});
pass('splits district and region when no street is supplied', () => {
  const place = helpers.toCatalogueRecord(row('L13', 'Albany Hotel, Washington Beach, Vice Beach', ['hotel', 'l1']), 1, true);
  assert.equal(place.name, 'Albany Hotel');
  assert.equal(place.street, '');
  assert.equal(place.district, 'Washington Beach');
  assert.equal(place.region, 'Vice Beach');
  assert.equal(place.area, 'Washington Beach · Vice Beach');
});
pass('does not invent a venue name for an unnamed record', () => {
  const place = helpers.toCatalogueRecord(row('L1', '?, Washington Beach, Vice Beach', ['hotel'], [1409.4, 2803.2], 'UNKNOWN'), 2, true);
  assert.equal(place.name, 'Unidentified location');
  assert.equal(place.nameEvidence, 'UNKNOWN');
  assert.equal(place.district, 'Washington Beach');
  assert.equal(place.region, 'Vice Beach');
});
pass('preserves a partly uncertain name instead of replacing it', () => {
  const place = helpers.toCatalogueRecord(row('L42', 'Parsons Hotel?, Shore Dr, Ocean Beach, Vice Beach', ['hotel'], [10, 10], 'UNKNOWN'), 3, true);
  assert.equal(place.name, 'Parsons Hotel?');
  assert.equal(place.nameEvidence, 'UNKNOWN');
});
pass('labels two-part area references without guessing street or district', () => {
  const place = helpers.toCatalogueRecord(row('L86', 'Fence, Vice Beach', ['hotel']), 4, true);
  assert.equal(place.name, 'Fence');
  assert.equal(place.areaReference, 'Vice Beach');
  assert.equal(place.street, '');
  assert.equal(place.district, '');
  assert.equal(place.region, '');
});
pass('keeps real-world contributor references separate from in-game labels', () => {
  const place = helpers.toCatalogueRecord(row('L25', 'Dominion Hotel, Shore Dr, Ocean Beach, Vice Beach', ['hotel']), 5, true);
  assert.equal(place.realWorldReference, 'Example reference, Miami, FL');
  assert.notEqual(place.realWorldReference, place.sourceAddress);
});
pass('filters residential, civic and leisure records into their own categories', () => {
  assert.equal(helpers.categoryFromTags(['residential']), 'residential');
  assert.equal(helpers.categoryFromTags(['government']), 'civic');
  assert.equal(helpers.categoryFromTags(['events']), 'leisure');
  assert.equal(helpers.categoryFromTags(['natural']), 'nature');
});
pass('visible markers shrink as the map zooms in while hit areas stay stable', () => {
  assert.match(source, /const MIN_MAP_ZOOM = 1;/);
  assert.equal(helpers.mapMarkerScale(1), 1);
  assert.equal(helpers.mapMarkerScale(5), 0.2);
  assert.ok(helpers.mapMarkerVisualScale(5) < helpers.mapMarkerVisualScale(1));
  assert.ok(fs.readFileSync(path.join(root, 'styles.css'), 'utf8').includes('transform:scale(var(--marker-hit-scale,1)) translate(-50%,-50%)'));
  assert.match(source, /state\.mapZoom >= 1\.5 \? ' cluster-dot-only'/);
});

const sample = JSON.parse(fs.readFileSync(path.join(root, 'sample-gtadb-snapshot.json'), 'utf8'));
const normalizedSample = sample.landmarks.map((record, index) => helpers.toCatalogueRecord(record, index, true)).filter(Boolean);
pass('normalizes the checked-in sample catalogue', () => {
  assert.equal(normalizedSample.length, 2);
  assert.equal(new Set(normalizedSample.map(place => place.id)).size, 2);
  assert.equal(normalizedSample.filter(place => Number.isFinite(place.x) && Number.isFinite(place.y)).length, 1);
});

const bundledPath = path.join(root, 'map-data', 'catalogue.js');
if (fs.existsSync(bundledPath)) {
  const bundledContext = { window: {} };
  vm.runInNewContext(fs.readFileSync(bundledPath, 'utf8'), bundledContext);
  const bundledRows = bundledContext.window.LEONIDA_BUNDLED_GTADB.landmarks;
  const normalized = bundledRows.map((record, index) => helpers.toCatalogueRecord(record, index, true)).filter(Boolean);
  pass('normalizes every locally generated bundled catalogue row', () => {
    assert.equal(normalized.length, 3431);
    assert.equal(new Set(normalized.map(place => place.id)).size, 3431);
    assert.equal(normalized.filter(place => Number.isFinite(place.x) && Number.isFinite(place.y)).length, 3340);
    assert.ok(normalized.every(place => place.name && place.type && place.category && Array.isArray(place.tags)));
  });
} else {
  process.stdout.write('SKIP full catalogue check (Gradle generates the bundled map-data folder during APK build).\n');
}
process.stdout.write(`\n${passed} map checks passed.\n`);
