# LEONIDA v0.9.2 — APK build-ready source project

**This ZIP is not itself an APK.** It now includes a GitHub Actions workflow that compiles, verifies and uploads an installable debug APK. The Android app itself has no `INTERNET` permission; the cloud workflow only builds the APK.

## New in v0.9.2

- `.github/workflows/build-apk.yml` builds the Android debug APK on a GitHub-hosted runner.
- Workflow installs JDK 17, Gradle 8.13, Android SDK Platform 36 and Build Tools 36.0.0.
- It runs JavaScript syntax checks and the seven finance calculation smoke tests before the Android compile.
- It verifies the APK signature with `apksigner` and produces a SHA-256 checksum.
- The resulting `LEONIDA-debug.apk` is uploaded as a GitHub Actions artifact for 14 days.
- A `.gitignore` excludes local builds, machine settings, and signing keys.

## How this gets an APK without your PC

1. Connect your GitHub account using the GitHub connection in ChatGPT.
2. Authorize creating a **private** repository for LEONIDA. The source code will be uploaded there so the cloud runner can build it; it will not be made public.
3. The workflow runs after the source is pushed to `main`. You can download `LEONIDA-debug.apk` from the run's Artifacts section using your phone.
4. Install the debug APK on your Galaxy S26. The first install may require allowing your browser/file manager to install apps from that source.

The GitHub connection and private repository creation still require your explicit account authorization. I have not uploaded your source to any external repository.

## Current app features

- Local Android WebView app shell and file import/backup bridge.
- Local map workspace: manual community basemap and GTADB catalogue import, search, filtering, place detail, saved pins, pan and zoom.
- Local waypoint routes (straight lines between stops; no street following or ETA).
- Session plans and editable objectives.
- User-entered in-game savings target and payout split calculator.
- Custom collectibles/activity/story/discovery checklist.
- Deterministic local command interface for map, routes, plans, money and checklist.
- Android on-device speech recognition and optional offline spoken responses, subject to the phone's installed offline language services.
- Portable JSON backups for map, catalogue, route, plans, finance and checklist.

## What is not magically included

- The app does not bundle Rockstar game assets or an official map.
- The community basemap and catalogue are separate files to import; their locations are not certified or official.
- Community map positions are approximate.
- The checklist is user-defined, not a complete official 100% checklist.
- Routes are direct waypoint-to-waypoint lines, not road navigation.
- The assistant is not connected to a cloud AI provider. Connecting an AI provider requires selecting a service and handling credentials safely. No API key, paid account or automatic billing is embedded in this project.

## Build configuration

- Application ID: `com.leonida.companion`
- Version: `0.9.2` (versionCode 13)
- Min Android API: 26
- Target Android API: 35
- Compile SDK: 36
- Android Gradle Plugin: 8.13.2
- Gradle: 8.13
- Java: 17

The workflow uses the GitHub-hosted Ubuntu runner and standard Android/Gradle build repositories. No local Android SDK or PC is needed once the private repository is authorized.

## Validation status

Source-level checks pass locally: JavaScript syntax, Android resource/manifest XML parsing, the seven payout calculation smoke tests, synchronized bundled web assets, and workflow file presence. **The APK is not yet compiled or signed here.** The workflow will perform the actual compilation and signature verification after the repository is authorized and the workflow runs.

## Permissions and offline behaviour

The installed Android app requests microphone permission only when voice input is explicitly used. It does not request Android internet permission; the WebView blocks remote web requests. The GitHub-hosted build process needs internet to obtain Android and Gradle build dependencies, but this does not add network access to the installed app.
