# LEONIDA v0.9.6 — Android companion source

## What's new in v0.9.6

- Bundles the YANIS v16 / GTADB community basemap and 3,431 searchable landmark records during the Android Gradle build.
- The build pins both upstream revisions and verifies the GTADB JSON SHA-256 before packaging.
- The built-in square basemap is fitted to the map viewport; zooming out cannot shrink it below the fitted view. Older map pan/zoom values reset on upgrade while other saved data is retained.
- Visible map dots shrink as you zoom in while transparent 28px hit targets remain easy to tap. Dense groups become compact dots at closer zoom levels.
- Location details separate names, street, district, region, area reference, and name confidence. Contributor real-world reference addresses are shown separately and clearly labelled as non-game references.
- Adds dedicated Residential, Civic / public, and Leisure filters instead of incorrectly grouping those records under Landmarks.
- Basemap and catalogue work offline once installed. The app itself still has no Android INTERNET permission.
- Adds a visible Settings control, map-data status, custom import and built-in map restore actions, plus backup/restore access.
- Map taps and double-taps no longer add markers. Use **Add pin**, then tap once to choose the location; Cancel exits placement mode.
- Map drag and two-finger pinch remain gestures. Zoom +/- buttons only zoom.

## Build

The existing GitHub Actions workflow can continue to compile the APK from this source ZIP. Gradle's `prepareCommunityAtlasAssets` task downloads the pinned public CC BY 4.0 source data on the build runner and packages it into the WebView assets before `preBuild`.

The source ZIP contains the Android project at its root. Replace the previous source ZIP in the repository, keeping the filename expected by your workflow (`LEONIDA-v0.9.2-source.zip`) or update the workflow's ZIP filename if you rename it.

## Bundled data sources and attribution

- GTADB / Map GTA and contributors, CC BY 4.0, revision `5c1d69ff864623d181da5457afaacd00b623e1a4`, SHA-256 checked by Gradle: `2209a4ff385815cad4d1f217248daaae3e29d029c34c137ce870eee1e8181083`.
- YANIS v16 / GTADB community basemap, CC BY 4.0, revision `0c7434f5bd5ed59a58aaa75a3ba7c3734fa0c4d0`.
- The SVG viewBox is cropped from `-32000 -24000 40000 40000` to `-16000 -8000 20000 20000` to match this app's GTADB coordinate projection.
- The map is a community reconstruction. Locations and positions are approximate, may be incomplete, and are not official Rockstar data.

CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
GTADB data: https://github.com/rolux/gtadb.org
Basemap source: https://github.com/navanem/gta6-leonida-atlas

## App limitations

- LEONIDA is independent and not affiliated with Rockstar Games or Take-Two Interactive.
- Routes connect stops with straight lines; they are not road navigation or ETA calculations.
- The local assistant is deterministic and is not connected to a cloud AI service.
- The completion checklist is user-defined, not an official 100% checklist.
- A debug APK is for testing. It is not a Play Store release build.

## Build configuration

- Application ID: `com.leonida.companion`
- Version: `0.9.6` (versionCode 17)
- Min Android API 26; target API 35; compile SDK 36
- Android Gradle Plugin 8.13.2; Gradle 8.13; Java 17


## v0.9.6 map polish

- Fit-to-frame is the minimum zoom; saved map views from older versions reset once after upgrade.
- Markers use finger-sized transparent hit areas while visible dots shrink as the map zooms in.
- Catalogue detail cards separate type, street, district, region, area reference, map position, and confidence. Contributor real-world references are labelled separately from in-game labels.
- Personal pins open a detail card with position, date, center, and delete actions.

Validation commands: `npm run check:js`, `npm run test:finance`, and `npm run test:map`.


The app displays contributor real-world reference addresses only as supporting context. They are not in-game street addresses and are not official Rockstar confirmations.
