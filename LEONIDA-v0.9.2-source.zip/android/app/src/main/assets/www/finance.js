(() => {
  'use strict';

  const FINANCE_KEY = 'leonida-finance-v1';
  const defaults = {
    money: { current: 0, target: 0, lastPayout: 0, gross: 100000, costs: 0, share: 50, history: [] },
    collectionItems: []
  };

  function safeAmount(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) return 0;
    return Math.max(0, Math.min(999999999, Math.floor(number)));
  }
  function formatCash(value) {
    return `GTA$${safeAmount(value).toLocaleString('en-US')}`;
  }
  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, char => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[char]));
  }
  function loadFinance() {
    try {
      const saved = JSON.parse(localStorage.getItem(FINANCE_KEY) || '{}');
      const money = saved.money && typeof saved.money === 'object' ? saved.money : {};
      return {
        money: {
          current: safeAmount(money.current),
          target: safeAmount(money.target),
          lastPayout: safeAmount(money.lastPayout),
          gross: Number.isFinite(money.gross) ? safeAmount(money.gross) : 100000,
          costs: safeAmount(money.costs),
          share: Number.isFinite(money.share) ? Math.max(0, Math.min(100, money.share)) : 50,
          history: Array.isArray(money.history) ? money.history.slice(0, 100) : []
        },
        collectionItems: Array.isArray(saved.collectionItems)
          ? saved.collectionItems.filter(item => item && typeof item.name === 'string').slice(0, 2000)
          : []
      };
    } catch {
      return structuredClone(defaults);
    }
  }

  let finance = loadFinance();
  let trackerFilter = 'all';

  function saveFinance() {
    try {
      localStorage.setItem(FINANCE_KEY, JSON.stringify(finance));
      return true;
    } catch {
      window.LEONIDA_TOAST?.('Finance data could not be saved. Export a backup and free some storage.');
      return false;
    }
  }
  function toast(message) {
    if (typeof window.LEONIDA_TOAST === 'function') window.LEONIDA_TOAST(message);
    else {
      const element = document.querySelector('#toast');
      if (element) {
        element.textContent = message;
        element.classList.add('show');
        clearTimeout(toast.timer);
        toast.timer = setTimeout(() => element.classList.remove('show'), 3000);
      }
    }
  }
  function calculatePayout(grossValue, costValue, shareValue) {
    const gross = safeAmount(grossValue);
    const costs = safeAmount(costValue);
    const share = Number(shareValue);
    if (!Number.isFinite(share) || share < 0 || share > 100) {
      return { valid: false, error: 'Your cut must be between 0% and 100%.' };
    }
    if (costs > gross) return { valid: false, error: 'Costs cannot be higher than the gross take.' };
    const pool = gross - costs;
    return { valid: true, gross, costs, share, pool, take: Math.floor(pool * share / 100) };
  }
  function calculateRunEstimate(current, target, averagePayout) {
    const gap = Math.max(0, safeAmount(target) - safeAmount(current));
    const average = safeAmount(averagePayout);
    return gap === 0 ? 0 : average > 0 ? Math.ceil(gap / average) : null;
  }

  function updatePayoutPreview() {
    const grossInput = document.querySelector('#payout-gross');
    const costsInput = document.querySelector('#payout-costs');
    const shareInput = document.querySelector('#payout-share');
    if (!grossInput || !costsInput || !shareInput) return null;
    const result = calculatePayout(grossInput.value, costsInput.value, shareInput.value);
    document.querySelector('#payout-share-label').textContent = `${Number(shareInput.value)}%`;
    const recordButton = document.querySelector('#record-payout');
    if (!result.valid) {
      document.querySelector('#payout-your-take').textContent = 'Check values';
      document.querySelector('#payout-pool-label').textContent = result.error;
      recordButton.disabled = true;
      return result;
    }
    document.querySelector('#payout-your-take').textContent = formatCash(result.take);
    document.querySelector('#payout-pool-label').textContent =
      `${formatCash(result.pool)} after costs · ${result.share}% share`;
    recordButton.disabled = false;
    return result;
  }
  function renderMoneyDesk() {
    const { money } = finance;
    document.querySelector('#money-current').value = money.current;
    document.querySelector('#money-target').value = money.target;
    document.querySelector('#payout-gross').value = money.gross;
    document.querySelector('#payout-costs').value = money.costs;
    document.querySelector('#payout-share').value = money.share;

    const remaining = Math.max(0, money.target - money.current);
    const percent = money.target > 0 ? Math.min(100, Math.floor(money.current / money.target * 100)) : 0;
    document.querySelector('#money-goal-fill').style.width = `${percent}%`;
    document.querySelector('#money-goal-percent').textContent = money.target > 0 ? `${percent}% reached` : 'Set a target';
    document.querySelector('#money-goal-remaining').textContent =
      money.target > 0 ? (remaining > 0 ? `${formatCash(remaining)} to go` : 'Target reached') : 'Enter your target above';

    const runCount = calculateRunEstimate(money.current, money.target, money.lastPayout);
    document.querySelector('#money-runs-estimate').textContent =
      money.target === 0 ? 'Set a target to estimate remaining runs.' :
      remaining === 0 ? 'Your target is reached.' :
      runCount === null ? 'Record a payout to estimate similar runs remaining.' :
      `About ${runCount.toLocaleString('en-US')} similar payout${runCount === 1 ? '' : 's'} at ${formatCash(money.lastPayout)} each.`;

    updatePayoutPreview();
    const recent = money.history.slice(0, 3);
    document.querySelector('#money-history').innerHTML = recent.length
      ? `<div class="money-history-heading"><strong>Recent recorded payouts</strong><small>${money.history.length} saved</small></div>` +
        recent.map(item => `<div class="money-history-row"><span><b>${formatCash(item.yourTake)}</b><small>${new Date(item.date).toLocaleDateString()} · ${item.share}% share</small></span><span>+${formatCash(item.yourTake)}</span></div>`).join('')
      : '<p class="money-history-empty">Payouts you record will appear here.</p>';
  }

  function saveMoneyGoal(current, target) {
    finance.money.current = safeAmount(current);
    finance.money.target = safeAmount(target);
    saveFinance();
    renderMoneyDesk();
    const remaining = Math.max(0, finance.money.target - finance.money.current);
    return finance.money.target
      ? `${formatCash(finance.money.current)} saved toward ${formatCash(finance.money.target)}. ${remaining > 0 ? `${formatCash(remaining)} remains.` : 'Target reached.'}`
      : `Current tracked balance set to ${formatCash(finance.money.current)}.`;
  }

  function recordPayout() {
    const result = updatePayoutPreview();
    if (!result?.valid) {
      toast(result?.error || 'Enter valid payout values.');
      return;
    }
    if (result.take <= 0) {
      toast('This payout adds nothing to your tracked balance.');
      return;
    }
    const entry = {
      id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())),
      date: new Date().toISOString(),
      gross: result.gross,
      costs: result.costs,
      share: result.share,
      pool: result.pool,
      yourTake: result.take
    };
    finance.money.current = safeAmount(finance.money.current + result.take);
    finance.money.lastPayout = result.take;
    finance.money.gross = result.gross;
    finance.money.costs = result.costs;
    finance.money.share = result.share;
    finance.money.history.unshift(entry);
    finance.money.history = finance.money.history.slice(0, 100);
    saveFinance();
    renderMoneyDesk();
    toast(`${formatCash(result.take)} added to your tracked balance.`);
  }

  function addChecklistItem(name, category = 'other') {
    const cleanName = String(name || '').trim();
    const allowed = ['collectible', 'activity', 'story', 'discovery', 'other'];
    if (!cleanName) return { ok: false, message: 'Enter a name for the checklist item.' };
    if (cleanName.length > 100) return { ok: false, message: 'Checklist names must be 100 characters or fewer.' };
    if (!allowed.includes(category)) category = 'other';
    if (finance.collectionItems.some(item => item.name.toLowerCase() === cleanName.toLowerCase() && item.category === category)) {
      return { ok: false, message: 'That item is already on your checklist in this category.' };
    }
    finance.collectionItems.unshift({
      id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
      name: cleanName,
      category,
      done: false,
      createdAt: new Date().toISOString()
    });
    saveFinance();
    renderTracker();
    return { ok: true, message: `Added “${cleanName}” to your ${category} checklist.` };
  }

  function renderTracker() {
    const items = finance.collectionItems;
    const done = items.filter(item => item.done).length;
    const percentage = items.length ? Math.round(done / items.length * 100) : 0;
    document.querySelector('#tracker-percent').textContent = `${percentage}%`;
    document.querySelector('#tracker-progress-fill').style.width = `${percentage}%`;
    document.querySelector('#tracker-count-label').textContent = `${done} / ${items.length} completed`;
    document.querySelector('#tracker-left-label').textContent = items.length ? `${items.length - done} remaining` : 'Add your first item';

    const visible = trackerFilter === 'all' ? items : items.filter(item => item.category === trackerFilter);
    const list = document.querySelector('#tracker-list');
    list.innerHTML = visible.length ? visible.map(item => `
      <div class="tracker-item ${item.done ? 'completed' : ''}">
        <label class="tracker-item-label">
          <input type="checkbox" data-tracker-id="${escapeHtml(item.id)}" ${item.done ? 'checked' : ''} />
          <span><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(item.category)}</small></span>
        </label>
        <button class="tracker-remove" data-remove-tracker="${escapeHtml(item.id)}" aria-label="Remove ${escapeHtml(item.name)}">×</button>
      </div>`).join('')
      : `<p class="tracker-empty">${items.length ? 'No items in this filter yet.' : 'Your custom list is empty. Add an item above to start tracking.'}</p>`;

    document.querySelectorAll('[data-tracker-id]').forEach(input => input.addEventListener('change', () => {
      const item = finance.collectionItems.find(entry => entry.id === input.dataset.trackerId);
      if (!item) return;
      item.done = input.checked;
      saveFinance();
      renderTracker();
    }));
    document.querySelectorAll('[data-remove-tracker]').forEach(button => button.addEventListener('click', () => {
      finance.collectionItems = finance.collectionItems.filter(entry => entry.id !== button.dataset.removeTracker);
      saveFinance();
      renderTracker();
      toast('Checklist item removed.');
    }));
    document.querySelectorAll('[data-tracker-filter]').forEach(button => {
      button.classList.toggle('active', button.dataset.trackerFilter === trackerFilter);
    });
  }

  function exportData() {
    return JSON.parse(JSON.stringify(finance));
  }
  function importData(data) {
    if (!data || typeof data !== 'object') return;
    const money = data.money && typeof data.money === 'object' ? data.money : {};
    finance = {
      money: {
        current: safeAmount(money.current),
        target: safeAmount(money.target),
        lastPayout: safeAmount(money.lastPayout),
        gross: Number.isFinite(money.gross) ? safeAmount(money.gross) : 100000,
        costs: safeAmount(money.costs),
        share: Number.isFinite(money.share) ? Math.max(0, Math.min(100, money.share)) : 50,
        history: Array.isArray(money.history) ? money.history.slice(0, 100) : []
      },
      collectionItems: Array.isArray(data.collectionItems) ? data.collectionItems.slice(0, 2000) : []
    };
    saveFinance();
    renderMoneyDesk();
    renderTracker();
  }

  function bindUi() {
    document.querySelector('#money-goal-form').addEventListener('submit', event => {
      event.preventDefault();
      toast(saveMoneyGoal(
        document.querySelector('#money-current').value,
        document.querySelector('#money-target').value
      ));
    });

    document.querySelector('#payout-form').addEventListener('submit', event => {
      event.preventDefault();
      const result = updatePayoutPreview();
      if (!result?.valid) toast(result?.error || 'Check the payout values.');
    });
    ['payout-gross', 'payout-costs', 'payout-share'].forEach(id => {
      document.querySelector(`#${id}`).addEventListener('input', () => {
        finance.money.gross = safeAmount(document.querySelector('#payout-gross').value);
        finance.money.costs = safeAmount(document.querySelector('#payout-costs').value);
        finance.money.share = Number(document.querySelector('#payout-share').value);
        saveFinance();
        updatePayoutPreview();
      });
    });
    document.querySelector('#record-payout').addEventListener('click', recordPayout);

    document.querySelector('#tracker-form').addEventListener('submit', event => {
      event.preventDefault();
      const result = addChecklistItem(
        document.querySelector('#tracker-name').value,
        document.querySelector('#tracker-category').value
      );
      if (!result.ok) {
        toast(result.message);
        return;
      }
      document.querySelector('#tracker-name').value = '';
      toast(result.message);
    });
    document.querySelectorAll('[data-tracker-filter]').forEach(button => button.addEventListener('click', () => {
      trackerFilter = button.dataset.trackerFilter;
      renderTracker();
    }));
  }

  function handleAssistantCommand(text) {
    const goalMatch = text.match(/^set (?:my )?(?:money|savings) goal(?: to)?\s+\$?([\d,]+)(?:\s+with\s+\$?([\d,]+)\s+saved)?[.!?]*$/i);
    if (goalMatch) {
      const target = Number(goalMatch[1].replace(/,/g, ''));
      const current = goalMatch[2] ? Number(goalMatch[2].replace(/,/g, '')) : finance.money.current;
      return saveMoneyGoal(current, target);
    }
    if (/^(show|what is|check) (?:my )?(?:money goal|savings goal|balance)[.!?]*$/i.test(text)) {
      const remaining = Math.max(0, finance.money.target - finance.money.current);
      return finance.money.target
        ? `${formatCash(finance.money.current)} / ${formatCash(finance.money.target)}. ${remaining > 0 ? `${formatCash(remaining)} remains.` : 'Target reached.'}`
        : `Your tracked balance is ${formatCash(finance.money.current)}. Set a target in Planner to track savings.`;
    }
    const addMatch = text.match(/^add (collectible|activity|story|discovery|other)(?: item)?\s*[:\-]\s*(.+)$/i);
    if (addMatch) {
      const result = addChecklistItem(addMatch[2], addMatch[1].toLowerCase());
      return result.message;
    }
    const completeMatch = text.match(/^mark (.+?) (?:as )?complete[.!?]*$/i);
    if (completeMatch) {
      const query = completeMatch[1].trim().toLowerCase();
      const matches = finance.collectionItems.filter(item => item.name.toLowerCase() === query);
      if (matches.length !== 1) {
        return matches.length ? 'More than one checklist item has that name. Choose it in Progress.'
          : `I couldn't find “${completeMatch[1]}” on your custom checklist.`;
      }
      matches[0].done = true;
      saveFinance();
      renderTracker();
      return `Marked “${matches[0].name}” complete.`;
    }
    return null;
  }

  function installAssistantExtension() {
    if (typeof window.respondToPrompt !== 'function' || typeof window.addMessage !== 'function') return;
    const original = window.respondToPrompt;
    window.respondToPrompt = function(raw) {
      const result = handleAssistantCommand(String(raw || '').trim());
      if (result === null) return original.call(this, raw);
      const clean = String(raw || '').trim();
      if (!clean) return;
      window.addMessage('user', clean);
      window.setTimeout(() => window.addMessage('assistant', result), 100);
    };
  }

  window.LEONIDA_FINANCE = {
    exportData,
    importData,
    calculatePayout,
    calculateRunEstimate,
    addChecklistItem,
    getSummary: () => ({
      money: exportData().money,
      completedItems: finance.collectionItems.filter(item => item.done).length,
      totalItems: finance.collectionItems.length
    })
  };

  // Wait until both the app shell and the DOM are ready.
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialise, { once: true });
  } else {
    initialise();
  }
  function initialise() {
    bindUi();
    renderMoneyDesk();
    renderTracker();
    installAssistantExtension();
  }
})();
