(() => {
  'use strict';

  const STORAGE_KEY = 'leonida-route-v1';
  let routeIds = [];
  const $ = selector => document.querySelector(selector);

  function load() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
      routeIds = Array.isArray(saved) ? [...new Set(saved.filter(id => typeof id === 'string'))].slice(0, 100) : [];
    } catch {
      routeIds = [];
    }
  }
  function save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(routeIds));
    } catch {
      showToast('Route could not be saved. Export a backup and free some app storage.');
    }
  }
  function showToast(message) {
    const el = $('#toast');
    if (!el) return;
    el.textContent = message;
    el.classList.add('show');
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => el.classList.remove('show'), 3000);
  }
  function mapApi() {
    return window.LEONIDA_MAP_API || null;
  }
  function routePlaces() {
    const api = mapApi();
    if (!api) return [];
    return routeIds.map(id => api.getPlace(id)).filter(Boolean);
  }
  function addPlace(id) {
    const api = mapApi();
    const place = api?.getPlace(id);
    if (!place) return { ok: false, message: 'That place is not in the imported catalogue.' };
    if (!api.isPlottable(place)) return { ok: false, message: 'That place has no safe map position for a waypoint.' };
    if (routeIds.includes(id)) return { ok: false, message: `${place.name} is already on your route.` };
    if (routeIds.length >= 50) return { ok: false, message: 'A route can contain up to 50 stops.' };
    routeIds.push(id);
    save();
    render();
    return { ok: true, message: `Added ${place.name} as stop ${routeIds.length}.` };
  }
  function removePlace(id) {
    const api = mapApi();
    const place = api?.getPlace(id);
    routeIds = routeIds.filter(value => value !== id);
    save();
    render();
    return { ok: true, message: `Removed ${place?.name || 'the stop'} from your route.` };
  }
  function movePlace(id, direction) {
    const index = routeIds.indexOf(id);
    if (index < 0) return { ok: false, message: 'That stop is not on your route.' };
    const next = direction === 'up' ? index - 1 : index + 1;
    if (next < 0 || next >= routeIds.length) return { ok: false, message: 'That stop is already at the route boundary.' };
    [routeIds[index], routeIds[next]] = [routeIds[next], routeIds[index]];
    save();
    render();
    return { ok: true, message: `Route order updated.` };
  }
  function clear() {
    routeIds = [];
    save();
    render();
    return { ok: true, message: 'Route cleared.' };
  }
  function exportData() {
    return routeIds.slice();
  }
  function importData(items) {
    routeIds = Array.isArray(items)
      ? [...new Set(items.filter(item => typeof item === 'string'))].slice(0, 50)
      : [];
    save();
    render();
  }
  function renderOverlay(places) {
    const svg = $('#route-overlay');
    if (!svg) return;
    const api = mapApi();
    const visible = places.filter(place => api?.isPlottable(place));
    if (visible.length < 2) {
      svg.innerHTML = '';
      return;
    }
    const points = visible.map(place => `${Number(place.x).toFixed(3)},${Number(place.y).toFixed(3)}`).join(' ');
    const dots = visible.map((place, index) =>
      `<circle cx="${Number(place.x).toFixed(3)}" cy="${Number(place.y).toFixed(3)}" r="1.4"></circle>` +
      `<text x="${Number(place.x).toFixed(3)}" y="${Number(place.y).toFixed(3)}" dx="2" dy="-1.8">${index + 1}</text>`
    ).join('');
    svg.innerHTML = `<polyline points="${points}" class="route-line"></polyline>${dots}`;
  }
  function render() {
    const api = mapApi();
    const list = $('#route-stops-list');
    if (!list) return;
    const places = routePlaces();
    const staleCount = routeIds.length - places.length;
    $('#route-stop-count').textContent = `${places.length} stop${places.length === 1 ? '' : 's'}`;
    $('#route-status').textContent = places.length < 2
      ? 'Add at least two mapped places to draw a line.'
      : 'Your chosen stop order is shown on the map.';
    list.innerHTML = places.length
      ? places.map((place, index) => `
          <article class="route-stop">
            <span class="route-stop-number">${index + 1}</span>
            <button class="route-stop-name" type="button" data-route-focus="${escapeAttr(place.id)}">
              <strong>${escapeText(place.name)}</strong>
              <small>${escapeText(place.region || place.category || 'Community map location')}</small>
            </button>
            <div class="route-stop-actions">
              <button type="button" data-route-up="${escapeAttr(place.id)}" aria-label="Move ${escapeAttr(place.name)} earlier" ${index === 0 ? 'disabled' : ''}>↑</button>
              <button type="button" data-route-down="${escapeAttr(place.id)}" aria-label="Move ${escapeAttr(place.name)} later" ${index === places.length - 1 ? 'disabled' : ''}>↓</button>
              <button type="button" data-route-remove="${escapeAttr(place.id)}" aria-label="Remove ${escapeAttr(place.name)}">×</button>
            </div>
          </article>`).join('')
      : `<p class="route-empty">${staleCount ? `${staleCount} saved stop(s) are unavailable in the current catalogue. Import the matching catalogue to restore them.` : 'No stops yet. Open a mapped place and tap “Add to route”.'}</p>`;

    renderOverlay(places);
    list.querySelectorAll('[data-route-focus]').forEach(button => button.addEventListener('click', () => {
      api?.focus(button.dataset.routeFocus);
    }));
    list.querySelectorAll('[data-route-up]').forEach(button => button.addEventListener('click', () => {
      movePlace(button.dataset.routeUp, 'up');
    }));
    list.querySelectorAll('[data-route-down]').forEach(button => button.addEventListener('click', () => {
      movePlace(button.dataset.routeDown, 'down');
    }));
    list.querySelectorAll('[data-route-remove]').forEach(button => button.addEventListener('click', () => {
      removePlace(button.dataset.routeRemove);
    }));
  }

  function escapeText(value) {
    return String(value ?? '').replace(/[&<>"']/g, ch => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[ch]));
  }
  function escapeAttr(value) { return escapeText(value).replace(/`/g, '&#96;'); }

  function routeCommand(text) {
    const input = String(text || '').trim();
    const lower = input.toLowerCase();

    if (/^(clear|delete|remove)\s+(my\s+)?route[.!?]*$/.test(lower)) {
      return clear().message;
    }
    if (/^(show|open|view)\s+(my\s+)?route[.!?]*$/.test(lower)) {
      document.querySelector('[data-screen="map"]')?.click();
      render();
      return routeIds.length
        ? `Your route has ${routePlaces().length} available stop(s). The route is shown below the map.`
        : 'Your route is empty. Open a mapped place and add it as a stop.';
    }
    const addMatch = input.match(/^add\s+(.+?)\s+to\s+(?:my\s+)?route[.!?]*$/i);
    if (addMatch) {
      const api = mapApi();
      const matches = api?.getPlaces().filter(place =>
        String(place.name || '').toLowerCase().includes(addMatch[1].toLowerCase())
      ) || [];
      if (!matches.length) return `I couldn't find “${addMatch[1]}” in your loaded catalogue.`;
      if (matches.length > 1) return `I found several matches for “${addMatch[1]}”. Search the Map tab and choose the exact place.`;
      return addPlace(matches[0].id).message;
    }
    const removeMatch = input.match(/^remove\s+(.+?)\s+from\s+(?:my\s+)?route[.!?]*$/i);
    if (removeMatch) {
      const api = mapApi();
      const target = removeMatch[1].toLowerCase();
      const place = routePlaces().find(item => String(item.name).toLowerCase() === target);
      if (!place) return `I couldn't find “${removeMatch[1]}” as an exact route stop.`;
      return removePlace(place.id).message;
    }
    const moveMatch = input.match(/^move\s+(.+?)\s+(up|down|earlier|later)[.!?]*$/i);
    if (moveMatch) {
      const place = routePlaces().find(item => String(item.name).toLowerCase() === moveMatch[1].toLowerCase());
      if (!place) return `I couldn't find “${moveMatch[1]}” on your route.`;
      return movePlace(place.id, /up|earlier/i.test(moveMatch[2]) ? 'up' : 'down').message;
    }
    return null;
  }

  function installAssistantCommands() {
    if (typeof window.respondToPrompt !== 'function' || typeof window.addMessage !== 'function') return;
    const previous = window.respondToPrompt;
    window.respondToPrompt = function(raw) {
      const result = routeCommand(raw);
      if (result === null) return previous.call(this, raw);
      const clean = String(raw || '').trim();
      if (!clean) return;
      window.addMessage('user', clean);
      window.setTimeout(() => window.addMessage('assistant', result), 100);
    };
  }

  window.LEONIDA_ROUTES = { addPlace, removePlace, movePlace, clear, render, exportData, importData };
  function initialise() {
    load();
    $('#clear-route-button')?.addEventListener('click', clear);
    document.addEventListener('leonida:map-data-changed', render);
    installAssistantCommands();
    render();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialise, { once: true });
  else initialise();
})();
