(() => {
  'use strict';

  const VOICE_PREF_KEY = 'leonida-voice-prefs-v1';
  const state = {
    speechAvailable: false,
    ttsAvailable: false,
    listening: false,
    speaking: false,
    speakReplies: false,
    nativeState: 'idle'
  };

  function toast(message) {
    const el = document.querySelector('#toast');
    if (!el) return;
    el.textContent = message;
    el.classList.add('show');
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => el.classList.remove('show'), 3200);
  }

  function loadPreferences() {
    try {
      const prefs = JSON.parse(localStorage.getItem(VOICE_PREF_KEY) || '{}');
      state.speakReplies = prefs.speakReplies === true;
    } catch {
      state.speakReplies = false;
    }
  }
  function savePreferences() {
    try {
      localStorage.setItem(VOICE_PREF_KEY, JSON.stringify({ speakReplies: state.speakReplies }));
    } catch {}
  }

  function renderState() {
    const mic = document.querySelector('#voice-input-button');
    const output = document.querySelector('#voice-replies-button');
    const status = document.querySelector('#voice-status');
    if (!mic || !output || !status) return;
    mic.classList.toggle('active', state.listening);
    mic.disabled = !state.speechAvailable && !window.AndroidBridge;
    mic.setAttribute('aria-label', state.listening ? 'Stop offline voice input' : 'Start offline voice input');
    output.classList.toggle('active', state.speakReplies);
    output.setAttribute('aria-pressed', String(state.speakReplies));
    const messages = [];
    if (state.listening) messages.push('Listening offline…');
    else if (state.nativeState === 'processing') messages.push('Recognizing speech…');
    else messages.push(state.speechAvailable ? 'Offline mic ready' : 'Offline speech unavailable');
    messages.push(state.speakReplies ? (state.ttsAvailable ? 'spoken replies on' : 'offline voice unavailable') : 'spoken replies off');
    status.textContent = messages.join(' · ');
  }

  function setCapabilities(speech, tts) {
    state.speechAvailable = speech === true;
    state.ttsAvailable = tts === true;
    renderState();
  }
  function setNativeState(value) {
    state.nativeState = String(value || 'idle');
    state.listening = state.nativeState === 'listening' || state.nativeState === 'processing';
    renderState();
  }
  function handleResult(text) {
    state.listening = false;
    state.nativeState = 'idle';
    renderState();
    const input = document.querySelector('#chat-input');
    const form = document.querySelector('#chat-form');
    if (!input || !form) return;
    input.value = String(text || '').trim();
    if (input.value) form.requestSubmit();
  }
  function handleError(message) {
    state.listening = false;
    state.nativeState = 'idle';
    renderState();
    toast(String(message || 'Voice action failed.'));
  }
  function speakReply(text) {
    if (!state.speakReplies || !state.ttsAvailable || !window.AndroidBridge) return;
    const clean = String(text || '').trim();
    if (!clean) return;
    window.AndroidBridge.speakText(clean.slice(0, 600));
  }
  function toggleSpeechInput() {
    if (!window.AndroidBridge) {
      toast('Offline voice input is only available in the installed Android app.');
      return;
    }
    if (state.listening) {
      window.AndroidBridge.stopOfflineSpeech();
      setNativeState('idle');
    } else {
      window.AndroidBridge.startOfflineSpeech();
    }
  }

  function initialise() {
    loadPreferences();
    document.querySelector('#voice-input-button')?.addEventListener('click', toggleSpeechInput);
    document.querySelector('#voice-replies-button')?.addEventListener('click', () => {
      state.speakReplies = !state.speakReplies;
      savePreferences();
      renderState();
      if (state.speakReplies && !state.ttsAvailable) {
        toast('No offline text-to-speech voice is ready on this phone.');
      } else {
        toast(state.speakReplies ? 'Spoken replies enabled.' : 'Spoken replies disabled.');
      }
    });
    renderState();
  }

  window.LEONIDA_VOICE = {
    setCapabilities,
    setNativeState,
    handleResult,
    handleError,
    speakReply
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialise, { once: true });
  } else {
    initialise();
  }
})();
