package com.leonida.companion;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Set;

public final class MainActivity extends Activity {
    private static final int REQUEST_PICK_FILE = 7010;
    private static final int REQUEST_SAVE_FILE = 7011;
    private static final int REQUEST_AUDIO_PERMISSION = 7012;
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String APP_URL = "https://" + APP_HOST + "/assets/www/index.html";

    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private ValueCallback<Uri[]> fileChooserCallback;
    private String pendingSaveContent;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private boolean offlineTtsReady = false;
    private boolean speechPermissionPending = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16, 16, 22));
        getWindow().setNavigationBarColor(Color.rgb(16, 16, 22));
        getWindow().getDecorView().setSystemUiVisibility(0);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(16, 16, 22));
        setContentView(webView);

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);

        // The JavaScript bridge is exposed only to the bundled app origin.
        webView.addJavascriptInterface(new LocalAppBridge(), "AndroidBridge");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try {
                    startActivityForResult(intent, REQUEST_PICK_FILE);
                    return true;
                } catch (ActivityNotFoundException error) {
                    fileChooserCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "No file picker is available.", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (url != null && url.startsWith(APP_URL.substring(0, APP_URL.lastIndexOf('/') + 1))) {
                    notifyVoiceCapability();
                }
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view,
                                                               WebResourceRequest request) {
                Uri uri = request.getUrl();
                WebResourceResponse local = assetLoader.shouldInterceptRequest(uri);
                if (local != null) return local;

                // Block every external HTTP(S) subresource as well as non-app hosts.
                if ("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme())) {
                    return new WebResourceResponse(
                            "text/plain",
                            "UTF-8",
                            403,
                            "Blocked",
                            java.util.Collections.emptyMap(),
                            new ByteArrayInputStream("External network access is disabled in this LEONIDA build.".getBytes(StandardCharsets.UTF_8))
                    );
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                // Only allow navigation within the bundled asset origin.
                return !("https".equalsIgnoreCase(uri.getScheme())
                        && APP_HOST.equalsIgnoreCase(uri.getHost()));
            }
        });

        initialiseTextToSpeech();

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(APP_URL);
        }
    }

    private void initialiseTextToSpeech() {
        textToSpeech = new TextToSpeech(this, status -> {
            offlineTtsReady = false;
            if (status != TextToSpeech.SUCCESS || textToSpeech == null) {
                notifyVoiceCapability();
                return;
            }
            try {
                Locale desired = Locale.getDefault();
                Set<Voice> voices = textToSpeech.getVoices();
                if (voices != null) {
                    Voice best = null;
                    for (Voice voice : voices) {
                        if (voice == null || voice.isNetworkConnectionRequired()) continue;
                        if (voice.getLocale() != null
                                && voice.getLocale().getLanguage().equals(desired.getLanguage())) {
                            best = voice;
                            break;
                        }
                        if (best == null) best = voice;
                    }
                    if (best != null && textToSpeech.setVoice(best) == TextToSpeech.SUCCESS) {
                        offlineTtsReady = true;
                    }
                }
                if (!offlineTtsReady) {
                    int language = textToSpeech.setLanguage(desired);
                    offlineTtsReady = language == TextToSpeech.LANG_AVAILABLE
                            || language == TextToSpeech.LANG_COUNTRY_AVAILABLE
                            || language == TextToSpeech.LANG_COUNTRY_VAR_AVAILABLE;
                    Voice active = textToSpeech.getVoice();
                    if (active != null && active.isNetworkConnectionRequired()) {
                        offlineTtsReady = false;
                    }
                }
            } catch (Exception ignored) {
                offlineTtsReady = false;
            }
            notifyVoiceCapability();
        });
    }

    private boolean isOfflineSpeechAvailable() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false;
        try {
            return SpeechRecognizer.isOnDeviceRecognitionAvailable(this);
        } catch (Exception ignored) {
            return false;
        }
    }

    private void startOfflineSpeechFromUi() {
        if (!isOfflineSpeechAvailable()) {
            sendVoiceError("Offline speech recognition is not available on this device. LEONIDA will not switch to online recognition.");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            speechPermissionPending = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO_PERMISSION);
            return;
        }
        startOfflineSpeech();
    }

    private void startOfflineSpeech() {
        runOnUiThread(() -> {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                    || !SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                sendVoiceError("Offline speech recognition is not installed or available.");
                return;
            }
            try {
                if (speechRecognizer != null) {
                    speechRecognizer.cancel();
                    speechRecognizer.destroy();
                    speechRecognizer = null;
                }
                speechRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
                speechRecognizer.setRecognitionListener(new RecognitionListener() {
                    @Override public void onReadyForSpeech(Bundle params) { sendVoiceState("listening"); }
                    @Override public void onBeginningOfSpeech() { sendVoiceState("listening"); }
                    @Override public void onRmsChanged(float rmsdB) {}
                    @Override public void onBufferReceived(byte[] buffer) {}
                    @Override public void onEndOfSpeech() { sendVoiceState("processing"); }
                    @Override public void onError(int error) {
                        sendVoiceState("idle");
                        String message = error == SpeechRecognizer.ERROR_NO_MATCH
                                ? "I didn't catch that. Try speaking a little more clearly."
                                : error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                                    ? "I didn't hear anything. Tap the microphone and try again."
                                    : "Offline speech recognition stopped. You can try again.";
                        sendVoiceError(message);
                    }
                    @Override public void onResults(Bundle results) {
                        sendVoiceState("idle");
                        if (results == null) {
                            sendVoiceError("No speech result was returned.");
                            return;
                        }
                        java.util.ArrayList<String> matches =
                                results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (matches == null || matches.isEmpty()) {
                            sendVoiceError("No words were recognized.");
                            return;
                        }
                        sendVoiceResult(matches.get(0));
                    }
                    @Override public void onPartialResults(Bundle partialResults) {}
                    @Override public void onEvent(int eventType, Bundle params) {}
                });

                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag());
                intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
                intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
                intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
                speechRecognizer.startListening(intent);
                sendVoiceState("listening");
            } catch (Exception error) {
                sendVoiceState("idle");
                sendVoiceError("Could not start offline speech recognition.");
            }
        });
    }

    private void stopOfflineSpeech() {
        runOnUiThread(() -> {
            if (speechRecognizer != null) {
                try { speechRecognizer.stopListening(); } catch (Exception ignored) {}
            }
            sendVoiceState("idle");
        });
    }

    private void speakOffline(String text) {
        if (text == null) return;
        String safeText = text.trim();
        if (safeText.isEmpty()) return;
        if (safeText.length() > 600) safeText = safeText.substring(0, 600);
        final String phrase = safeText;
        runOnUiThread(() -> {
            if (!offlineTtsReady || textToSpeech == null) {
                sendVoiceError("No offline text-to-speech voice is available. Install an offline voice in Android settings to use spoken replies.");
                return;
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    textToSpeech.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "LEONIDA_REPLY");
                } else {
                    textToSpeech.speak(phrase, TextToSpeech.QUEUE_FLUSH, null);
                }
            } catch (Exception error) {
                sendVoiceError("Could not play the offline spoken reply.");
            }
        });
    }

    private void notifyVoiceCapability() {
        boolean speech = isOfflineSpeechAvailable();
        boolean tts = offlineTtsReady;
        runOnUiThread(() -> evaluateJs(
                "window.LEONIDA_VOICE && window.LEONIDA_VOICE.setCapabilities("
                        + speech + "," + tts + ");"
        ));
    }

    private void sendVoiceState(String state) {
        String quoted = JSONObject.quote(state);
        runOnUiThread(() -> evaluateJs(
                "window.LEONIDA_VOICE && window.LEONIDA_VOICE.setNativeState(" + quoted + ");"
        ));
    }

    private void sendVoiceResult(String result) {
        String quoted = JSONObject.quote(result);
        runOnUiThread(() -> evaluateJs(
                "window.LEONIDA_VOICE && window.LEONIDA_VOICE.handleResult(" + quoted + ");"
        ));
    }

    private void sendVoiceError(String message) {
        String quoted = JSONObject.quote(message);
        runOnUiThread(() -> evaluateJs(
                "window.LEONIDA_VOICE && window.LEONIDA_VOICE.handleError(" + quoted + ");"
        ));
    }

    private void evaluateJs(String script) {
        if (webView != null) webView.evaluateJavascript(script, null);
    }

    private final class LocalAppBridge {
        @JavascriptInterface
        public void saveTextFile(String fileName, String contents) {
            if (contents == null || contents.length() > 20 * 1024 * 1024) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Backup is too large to export.", Toast.LENGTH_LONG).show());
                return;
            }
            runOnUiThread(() -> {
                pendingSaveContent = contents;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE,
                        (fileName == null || fileName.trim().isEmpty()) ? "leonida-backup.json" : fileName);
                try {
                    startActivityForResult(intent, REQUEST_SAVE_FILE);
                } catch (ActivityNotFoundException error) {
                    pendingSaveContent = null;
                    Toast.makeText(MainActivity.this, "No file save location is available.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void startOfflineSpeech() {
            runOnUiThread(MainActivity.this::startOfflineSpeechFromUi);
        }

        @JavascriptInterface
        public void stopOfflineSpeech() {
            MainActivity.this.stopOfflineSpeech();
        }

        @JavascriptInterface
        public void speakText(String text) {
            MainActivity.this.speakOffline(text);
        }

        @JavascriptInterface
        public boolean isOfflineSpeechAvailable() {
            return MainActivity.this.isOfflineSpeechAvailable();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO_PERMISSION) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted && speechPermissionPending) {
                speechPermissionPending = false;
                startOfflineSpeech();
            } else {
                speechPermissionPending = false;
                sendVoiceError("Microphone permission was not granted.");
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PICK_FILE) {
            if (fileChooserCallback != null) {
                Uri[] result = resultCode == RESULT_OK && data != null && data.getData() != null
                        ? new Uri[]{data.getData()} : null;
                fileChooserCallback.onReceiveValue(result);
                fileChooserCallback = null;
            }
            return;
        }
        if (requestCode == REQUEST_SAVE_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingSaveContent != null) {
                try (OutputStream output = getContentResolver().openOutputStream(data.getData())) {
                    if (output == null) throw new IllegalStateException("Could not open the selected file.");
                    output.write(pendingSaveContent.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "LEONIDA backup saved.", Toast.LENGTH_LONG).show();
                } catch (Exception error) {
                    Toast.makeText(this, "Could not save the backup: " + error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            pendingSaveContent = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (fileChooserCallback != null) {
            fileChooserCallback.onReceiveValue(null);
            fileChooserCallback = null;
        }
        if (speechRecognizer != null) {
            try { speechRecognizer.cancel(); } catch (Exception ignored) {}
            speechRecognizer.destroy();
            speechRecognizer = null;
        }
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
            textToSpeech = null;
        }
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
