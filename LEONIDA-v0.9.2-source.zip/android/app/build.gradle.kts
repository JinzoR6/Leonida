plugins {
    id("com.android.application")
}

android {
    namespace = "com.leonida.companion"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.leonida.companion"
        minSdk = 26
        targetSdk = 35
        versionCode = 13
        versionName = "0.9.2"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
