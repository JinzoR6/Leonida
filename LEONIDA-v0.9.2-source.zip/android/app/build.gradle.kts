import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.net.URL
import java.security.MessageDigest
import java.nio.charset.StandardCharsets

plugins {
    id("com.android.application")
}

android {
    namespace = "com.leonida.companion"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.leonida.companion"
        minSdk = 26
        targetSdk = 35
        versionCode = 17
        versionName = "0.9.6"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}


// Download and package the pinned CC BY 4.0 community basemap/catalogue at build time.
// The installed application remains offline: no INTERNET permission or runtime request is added.
val prepareCommunityAtlasAssets by tasks.registering {
    val outputDir = layout.projectDirectory.dir("src/main/assets/www/map-data")
    outputs.dir(outputDir)
    outputs.upToDateWhen { false }
    doLast {
        // The Android wrapper serves files from app/src/main/assets/www, while the
        // maintained web application lives at the repository root. Always sync the
        // current UI before packaging so the APK cannot ship stale controls.
        val repositoryRoot = rootProject.projectDir.parentFile
        val webAssetsDir = layout.projectDirectory.dir("src/main/assets/www").asFile
        val webFiles = listOf(
            "index.html", "app.js", "finance.js", "voice.js", "route.js",
            "styles.css", "manifest.webmanifest", "sw.js"
        )
        webFiles.forEach { name ->
            val source = repositoryRoot.resolve(name)
            check(source.isFile) { "Required web app file is missing: ${source.absolutePath}" }
            source.copyTo(webAssetsDir.resolve(name), overwrite = true)
        }
        val sourceIcons = repositoryRoot.resolve("assets")
        if (sourceIcons.isDirectory) {
            sourceIcons.copyRecursively(webAssetsDir.resolve("assets"), overwrite = true)
        }

        val dataRevision = "5c1d69ff864623d181da5457afaacd00b623e1a4"
        val dataSha256 = "2209a4ff385815cad4d1f217248daaae3e29d029c34c137ce870eee1e8181083"
        val dataUrl = "https://raw.githubusercontent.com/rolux/gtadb.org/$dataRevision/map/data/6/landmarks.json"
        val basemapRevision = "0c7434f5bd5ed59a58aaa75a3ba7c3734fa0c4d0"
        val basemapUrl = "https://raw.githubusercontent.com/navanem/gta6-leonida-atlas/$basemapRevision/public/assets/gta6-leonida-atlas/basemap.svg"
        val dataBytes = URL(dataUrl).openConnection().apply {
            connectTimeout = 30000
            readTimeout = 60000
            setRequestProperty("User-Agent", "LEONIDA-Android-Companion/0.9.6")
        }.getInputStream().use { it.readBytes() }
        val actualHash = MessageDigest.getInstance("SHA-256").digest(dataBytes).joinToString("") { "%02x".format(it.toInt() and 0xff) }
        check(actualHash == dataSha256) { "GTADB source checksum mismatch: $actualHash" }

        @Suppress("UNCHECKED_CAST")
        val sourceRows = JsonSlurper().parseText(String(dataBytes, StandardCharsets.UTF_8)) as Map<String, List<Any?>>
        check(sourceRows.size == 3431) { "Unexpected GTADB record count: ${sourceRows.size}" }
        val uncertaintyPatterns = listOf(
            "unconfirmed" to Regex("\\bun(?:confirmed|comfirmed)\\b", RegexOption.IGNORE_CASE),
            "may-not-exist" to Regex("\\bmay(?:-not-|not\\s+)exist\\b", RegexOption.IGNORE_CASE),
            "cancelled" to Regex("\\bcancelled\\b", RegexOption.IGNORE_CASE),
            "fictional" to Regex("\\bfictional\\b", RegexOption.IGNORE_CASE),
            "demolished" to Regex("\\bdemolished\\b", RegexOption.IGNORE_CASE),
            "duplicate" to Regex("\\bduplicate\\b", RegexOption.IGNORE_CASE)
        )
        var positionedCount = 0
        val landmarks = sourceRows.entries.map { entry ->
            val id = entry.key
            val row = entry.value
            check(Regex("L\\d+").matches(id) && row.size == 9) { "Invalid GTADB row $id" }
            val rawName = row[0] as? String ?: error("Missing place name for $id")
            val rawPosition = row[1] as? List<*>
            val coordinates = if (rawPosition != null && rawPosition.size == 2 && rawPosition.all { it is Number }) {
                listOf((rawPosition[0] as Number).toDouble(), (rawPosition[1] as Number).toDouble()).also { positionedCount++ }
            } else null
            val rawTags = row[6] as? List<*> ?: emptyList<Any?>()
            val tags = rawTags.filterIsInstance<String>()
            val signals = listOf(rawName) + tags
            val uncertain = uncertaintyPatterns.filter { (_, pattern) -> signals.any { pattern.containsMatchIn(it) } }.map { it.first }
            val unknownName = rawName.isBlank() || rawName.contains("?")
            val levelTags = tags.filter { Regex("l\\d+", RegexOption.IGNORE_CASE).matches(it) }
            val unconfirmed = uncertain.any { it in listOf("unconfirmed", "may-not-exist", "fictional", "cancelled") }
            val demolished = uncertain.contains("demolished")
            mapOf(
                "id" to id,
                "inGameAddress" to rawName,
                "inGameCoordinates" to coordinates,
                "realWorldReference" to (row.getOrNull(3) as? String)?.trim()?.take(200),
                "tags" to tags,
                "confidence" to if (unknownName) "UNKNOWN" else "SUPPORTED",
                "evidence" to mapOf(
                    "name" to if (unknownName) "UNKNOWN" else "KNOWN",
                    "placement" to if (coordinates != null) "APPROXIMATE" else "UNKNOWN",
                    "tagSignals" to mapOf("levelTags" to levelTags, "unconfirmed" to unconfirmed, "demolished" to demolished)
                )
            )
        }
        check(positionedCount == 3340) { "Unexpected positioned GTADB count: $positionedCount" }

        val attribution = "GTADB / Map GTA and contributors — CC BY 4.0. Community locations and coordinates are approximate; this is not an official Rockstar map."
        val snapshot = mapOf(
            "source" to mapOf(
                "name" to "GTADB / Map GTA community reconstruction",
                "repository" to "https://github.com/rolux/gtadb.org",
                "preferredSource" to "https://map.gtadb.org",
                "rawUrl" to dataUrl,
                "revision" to dataRevision,
                "license" to "CC BY 4.0",
                "licenseUrl" to "https://creativecommons.org/licenses/by/4.0/",
                "sha256" to dataSha256,
                "attribution" to attribution,
                "presentation" to "Community reconstruction; positions are approximate and may be incomplete."
            ),
            "counts" to mapOf("recordCount" to sourceRows.size, "positionedCount" to positionedCount, "unpositionedCount" to sourceRows.size - positionedCount),
            "landmarks" to landmarks
        )

        val basemapBytes = URL(basemapUrl).openConnection().apply {
            connectTimeout = 30000
            readTimeout = 60000
            setRequestProperty("User-Agent", "LEONIDA-Android-Companion/0.9.6")
        }.getInputStream().use { it.readBytes() }
        var basemap = String(basemapBytes, StandardCharsets.UTF_8)
        val originalViewBox = "viewBox=\"-32000 -24000 40000 40000\""
        check(basemap.startsWith("<svg") && basemap.contains(originalViewBox)) { "Unexpected YANIS v16 basemap geometry; refusing to package a mismatched map." }
        // Crop the SVG to the exact coordinate window used by the companion's GTADB marker projection.
        basemap = basemap.replace(originalViewBox, "viewBox=\"-16000 -8000 20000 20000\"")

        val out = outputDir.asFile
        out.mkdirs()
        out.resolve("leonida-basemap.svg").writeText(basemap, Charsets.UTF_8)
        out.resolve("catalogue.js").writeText(
            "window.LEONIDA_BUNDLED_GTADB = ${JsonOutput.toJson(snapshot)};\n" +
            "window.LEONIDA_BUNDLED_MAP = { available: true, coordinateSystem: 'gtadb-v16', basemapRevision: '$basemapRevision', dataRevision: '$dataRevision' };\n",
            Charsets.UTF_8
        )
        out.resolve("ATTRIBUTION.txt").writeText(
            "Basemap: YANIS v16 / GTADB community reconstruction, revision $basemapRevision, CC BY 4.0.\n" +
            "$attribution\n" +
            "Changes: the original square basemap viewBox was cropped to -16000 -8000 20000 20000 to align with the companion's displayed coordinate bounds. Contributor reference addresses are shown separately from in-game map labels.\n" +
            "The project is independent and is not affiliated with Rockstar Games or Take-Two Interactive.\n",
            Charsets.UTF_8
        )
        println("Packaged YANIS v16 community basemap and $positionedCount positioned GTADB locations (${sourceRows.size} total records).")
    }
}

tasks.named("preBuild").configure {
    dependsOn(prepareCommunityAtlasAssets)
}

