# LEONIDA Android v0.9.6

- Application ID: `com.leonida.companion`
- Version: `0.9.6` (versionCode 17)
- Minimum Android API 26, target API 35, compile SDK 36
- Java 17, Android Gradle Plugin 8.13.2, Gradle 8.13

The Android build packages the latest web UI and downloads pinned CC BY 4.0 community basemap/catalogue assets during the build. The installed app remains offline.

Map details distinguish in-game community labels from contributor real-world reference addresses. Map pins shrink visually as you zoom in, while their tap targets remain phone-friendly. The fit zoom is the minimum zoom.
