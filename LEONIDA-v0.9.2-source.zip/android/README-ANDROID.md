# LEONIDA Android v0.9.3

The Android app is an offline-first WebView wrapper. Its Gradle `prepareCommunityAtlasAssets` task downloads a pinned YANIS v16 / GTADB community basemap and a GTADB landmark snapshot, verifies the landmark JSON checksum and packages both into the APK assets before the Android asset merge.

The installed app does not receive Android INTERNET permission. The build runner needs internet access only to fetch the pinned public CC BY 4.0 community map sources at compile time.

- Application ID: `com.leonida.companion`
- Version: `0.9.3` (versionCode 14)
- minSdk: 26
- targetSdk: 35
- compileSdk: 36
- Android Gradle Plugin: 8.13.2
- Gradle: 8.13
- Java: 17

The basemap and GTADB locations are community reconstructions, approximate and not official Rockstar data. Attribution and source revisions are shown in the app Settings screen and in the bundled `map-data/ATTRIBUTION.txt` file.
