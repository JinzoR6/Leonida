const STORAGE_KEY = 'leonida-companion-v3';
const DB_NAME = 'leonida-local-v1';
const GTADB_REVISION = '5c1d69ff864623d181da5457afaacd00b623e1a4';
const GTADB_ATTRIBUTION = 'GTADB / Map GTA contributors · CC BY 4.0';
const GTADB_SOURCE_URL = 'https://github.com/navanem/gta6-leonida-atlas';
const GTADB_BOUNDS = { west: -16000, east: 4000, south: -8000, north: 12000 };
const MIN_MAP_ZOOM = 1; // 1.0 is the fitted frame; zooming out past fit is disabled.
const MAX_MAP_ZOOM = 5;

const state = {
  screen: 'map',
  plans: [],
  pins: [],
  locations: [],
  catalogueMeta: null,
  catalogueCoordinateSystem: 'percent',
  mapCompatible: false,
  pendingPin: null,
  pinPlacementMode: false,
  mapImageLoaded: false,
  mapSource: 'none',
  mapZoom: 1,
  mapPanX: 0,
  mapPanY: 0,
  mapCategory: 'all',
  selectedPlaceId: null,
  mapPointers: new Map(),
  mapGesture: null,
  mapClusters: new Map()
};

const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];
let mapObjectUrl = null;
let mapClusterRefreshPending = false;

function openLocalDb() {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) return reject(new Error('IndexedDB is unavailable.'));
    const request = indexedDB.open(DB_NAME, 2);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains('assets')) db.createObjectStore('assets');
      if (!db.objectStoreNames.contains('catalogue')) db.createObjectStore('catalogue');
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Could not open local storage.'));
  });
}
async function dbGet(storeName, key) {
  const db = await openLocalDb();
  const result = await new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const request = tx.objectStore(storeName).get(key);
    request.onsuccess = () => resolve(request.result ?? null);
    request.onerror = () => reject(request.error || new Error('Could not read local data.'));
  });
  db.close();
  return result;
}
async function dbPut(storeName, key, value) {
  const db = await openLocalDb();
  await new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    tx.objectStore(storeName).put(value, key);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error || new Error('Could not save local data.'));
    tx.onabort = () => reject(tx.error || new Error('Local save was cancelled.'));
  });
  db.close();
}
async function dbDelete(storeName, key) {
  const db = await openLocalDb();
  await new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    tx.objectStore(storeName).delete(key);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error || new Error('Could not delete local data.'));
  });
  db.close();
}
async function putMapBlob(blob) { return dbPut('assets', 'map-image', blob); }
async function getMapBlob() { return dbGet('assets', 'map-image'); }
async function clearMapBlob() { return dbDelete('assets', 'map-image'); }

async function persistCatalogue(items, meta, coordinateSystem) {
  // Write the full catalogue in one IndexedDB transaction; never put thousands of records in localStorage.
  await dbPut('catalogue', 'public-catalogue', {
    items,
    meta,
    coordinateSystem,
    savedAt: new Date().toISOString()
  });
}
async function initialiseCatalogueStorage() {
  try {
    const stored = await dbGet('catalogue', 'public-catalogue');
    const hasBundledCatalogue = Boolean(window.LEONIDA_BUNDLED_GTADB && Array.isArray(window.LEONIDA_BUNDLED_GTADB.landmarks));
    if (stored && Array.isArray(stored.items)) {
      state.locations = stored.items;
      state.catalogueMeta = stored.meta || null;
      state.catalogueCoordinateSystem = stored.coordinateSystem || 'percent';
      // Re-parse the bundled GTADB rows when its detail schema changes. This upgrades
      // existing on-device catalogues without deleting user-imported extra records.
      if (hasBundledCatalogue && state.catalogueCoordinateSystem === 'gtadb-v16' &&
          Number(state.catalogueMeta?.catalogueSchema || 0) < 4) {
        await importLocationsText(JSON.stringify(window.LEONIDA_BUNDLED_GTADB));
      }
    } else if (hasBundledCatalogue) {
      // First launch or legacy localStorage migration: merge the bundled catalogue
      // with any small legacy entries, then persist the normalized format in IndexedDB.
      await importLocationsText(JSON.stringify(window.LEONIDA_BUNDLED_GTADB));
    } else if (Array.isArray(state.locations) && state.locations.length) {
      await persistCatalogue(state.locations, state.catalogueMeta, state.catalogueCoordinateSystem);
    }
    if (hasBundledCatalogue && state.catalogueCoordinateSystem === 'gtadb-v16' && window.LEONIDA_BUNDLED_MAP?.available) {
      state.mapCompatible = true;
      saveState();
    }
    renderMapPins($('#map-search').value);
    updateCatalogueCount();
    updateMapSettingsStatus();
  } catch (error) {
    toast(`Catalogue storage error: ${error.message}`);
  }
}
function loadState() {
  try {
    const saved = JSON.parse(
      localStorage.getItem(STORAGE_KEY) ||
      localStorage.getItem('leonida-companion-v2') ||
      localStorage.getItem('leonida-companion-v1') ||
      '{}'
    );
    state.plans = Array.isArray(saved.plans) ? saved.plans : [];
    state.pins = Array.isArray(saved.pins) ? saved.pins : [];
    // v0.4 stored small catalogues here. Large ones are migrated to IndexedDB at startup.
    state.locations = Array.isArray(saved.locations) ? saved.locations : [];
    state.catalogueMeta = saved.catalogueMeta || null;
    state.catalogueCoordinateSystem = saved.catalogueCoordinateSystem || 'percent';
    state.mapCompatible = saved.mapCompatible === true;
    const currentMapView = saved.mapViewRevision === 4;
    state.mapZoom = currentMapView && Number.isFinite(saved.mapZoom) ? Math.max(MIN_MAP_ZOOM, Math.min(MAX_MAP_ZOOM, saved.mapZoom)) : 1;
    state.mapPanX = currentMapView && Number.isFinite(saved.mapPanX) ? saved.mapPanX : 0;
    state.mapPanY = currentMapView && Number.isFinite(saved.mapPanY) ? saved.mapPanY : 0;
  } catch {
    state.plans = [];
    state.pins = [];
    state.locations = [];
    toast('Saved data could not be read. Import a backup if you have one.');
  }
}
function saveState() {
  try {
    // Large catalogue records live in IndexedDB; localStorage is reserved for small preferences/plans.
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      version: 4,
      mapViewRevision: 4,
      plans: state.plans,
      pins: state.pins,
      catalogueMeta: state.catalogueMeta,
      catalogueCoordinateSystem: state.catalogueCoordinateSystem,
      mapCompatible: state.mapCompatible,
      mapZoom: state.mapZoom,
      mapPanX: state.mapPanX,
      mapPanY: state.mapPanY
    }));
  } catch {
    toast('Local storage is full. Export a backup before clearing app data.');
  }
}
function toast(message) {
  const el = $('#toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove('show'), 3200);
}
function switchScreen(name) {
  state.screen = name;
  $$('.screen').forEach(el => el.classList.toggle('active', el.id === `screen-${name}`));
  $$('.nav-item').forEach(el => el.classList.toggle('selected', el.dataset.screen === name));
  if (name === 'planner') renderPlans();
  if (name === 'progress') renderProgress();
  if (name === 'settings') updateMapSettingsStatus();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function safeText(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[char]));
}
function totalObjectives() { return state.plans.reduce((sum, plan) => sum + plan.tasks.length, 0); }
function completedObjectives() { return state.plans.reduce((sum, plan) => sum + plan.tasks.filter(task => task.done).length, 0); }

function renderPlans() {
  const root = $('#plans-list');
  if (!state.plans.length) {
    root.innerHTML = `<div class="empty-state"><div class="empty-glyph">＋</div><h2>No plans yet</h2><p>Create a session plan to keep objectives and notes together.</p><button class="primary-button" id="empty-new-plan">Create your first plan</button></div>`;
    $('#empty-new-plan').addEventListener('click', openPlanDialog);
    return;
  }
  root.innerHTML = state.plans.map(plan => {
    const done = plan.tasks.filter(task => task.done).length;
    const pct = plan.tasks.length ? Math.round(done / plan.tasks.length * 100) : 0;
    return `<article class="plan-card" data-plan="${safeText(plan.id)}">
      <div class="plan-top"><div><span class="plan-kicker">${safeText(plan.focus)} · ${safeText(plan.time)}</span><h2>${safeText(plan.name)}</h2></div><button class="more-button" data-delete="${safeText(plan.id)}" aria-label="Delete plan">···</button></div>
      ${plan.notes ? `<p class="plan-notes">${safeText(plan.notes)}</p>` : ''}
      <div class="progress-line"><span style="width:${pct}%"></span></div>
      <div class="plan-progress-label"><span>${done}/${plan.tasks.length} objectives complete</span><b>${pct}%</b></div>
      <div class="task-list">${plan.tasks.map((task,index)=>`<div class="task-row ${task.done?'done':''}"><label><input type="checkbox" data-task-plan="${safeText(plan.id)}" data-task-index="${index}" ${task.done?'checked':''}><span>${safeText(task.label)}</span></label><button class="task-remove" data-remove-task="${safeText(plan.id)}" data-task-index="${index}" aria-label="Remove objective">×</button></div>`).join('')}</div>
      <form class="task-add" data-add-task="${safeText(plan.id)}"><input name="task" maxlength="120" required placeholder="Add an objective…" aria-label="New objective"><button type="submit">Add</button></form>
    </article>`;
  }).join('');
  $$('[data-task-plan]').forEach(input => input.addEventListener('change', () => {
    const plan = state.plans.find(item => item.id === input.dataset.taskPlan);
    if (plan && plan.tasks[Number(input.dataset.taskIndex)]) plan.tasks[Number(input.dataset.taskIndex)].done = input.checked;
    saveState(); renderPlans(); renderProgress();
  }));
  $$('[data-delete]').forEach(button => button.addEventListener('click', () => {
    const plan = state.plans.find(item => item.id === button.dataset.delete);
    if (!plan || !confirm(`Delete “${plan.name}”?`)) return;
    state.plans = state.plans.filter(item => item.id !== plan.id);
    saveState(); renderPlans(); renderProgress(); toast('Plan deleted.');
  }));
  $$('[data-remove-task]').forEach(button => button.addEventListener('click', () => {
    const plan = state.plans.find(item => item.id === button.dataset.removeTask);
    const index = Number(button.dataset.taskIndex);
    if (!plan || !Number.isInteger(index) || !plan.tasks[index]) return;
    plan.tasks.splice(index, 1);
    saveState(); renderPlans(); renderProgress();
  }));
  $$('[data-add-task]').forEach(form => form.addEventListener('submit', event => {
    event.preventDefault();
    const plan = state.plans.find(item => item.id === form.dataset.addTask);
    const input = form.querySelector('input[name="task"]');
    const label = input.value.trim();
    if (!plan || !label) return;
    plan.tasks.push({ label, done: false });
    saveState(); renderPlans(); renderProgress(); toast('Objective added.');
  }));
}
function renderProgress() {
  const total = totalObjectives(), done = completedObjectives(), left = total - done;
  $('#stat-plans').textContent = state.plans.length;
  $('#stat-done').textContent = done;
  $('#stat-left').textContent = left;
  $('#stat-rate').textContent = total ? `${Math.round(done / total * 100)}%` : '0%';
}
function openPlanDialog() {
  $('#plan-name').value = '';
  $('#plan-notes').value = '';
  $('#plan-dialog').showModal();
  setTimeout(() => $('#plan-name').focus(), 50);
}
function makePlan({ name, focus = 'Custom objectives', time = '30 minutes', notes = '' }) {
  const plan = {
    id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())),
    name: name || 'New plan', focus, time, notes,
    createdAt: new Date().toISOString(),
    tasks: [
      { label: 'Review current objectives and requirements', done: false },
      { label: 'Choose the order for this session', done: false },
      { label: 'Record results and update progress', done: false }
    ]
  };
  state.plans.unshift(plan); saveState(); renderPlans(); renderProgress(); return plan;
}

function mapPlaceVisible(place) {
  return Number.isFinite(place.x) && Number.isFinite(place.y) &&
    (place.coordinateSystem !== 'gtadb-v16' || state.mapCompatible);
}
function clampMapPan() {
  const viewport = $('#local-map');
  const content = $('#map-content');
  if (!viewport || !content) return;
  const viewWidth = viewport.clientWidth;
  const viewHeight = viewport.clientHeight;
  const mapWidth = content.offsetWidth || viewWidth;
  const mapHeight = content.offsetHeight || viewHeight;
  const maxX = Math.max(0, (mapWidth * state.mapZoom - viewWidth) / 2);
  const maxY = Math.max(0, (mapHeight * state.mapZoom - viewHeight) / 2);
  state.mapPanX = Math.max(-maxX, Math.min(maxX, state.mapPanX));
  state.mapPanY = Math.max(-maxY, Math.min(maxY, state.mapPanY));
}
function updateMapZoomControls() {
  const zoomOut = $('#map-zoom-out');
  const zoomIn = $('#map-zoom-in');
  if (zoomOut) zoomOut.disabled = state.mapZoom <= MIN_MAP_ZOOM + 0.001;
  if (zoomIn) zoomIn.disabled = state.mapZoom >= MAX_MAP_ZOOM - 0.001;
}
function applyMapZoom() {
  const content = $('#map-content');
  if (!content) return;
  state.mapZoom = Math.max(MIN_MAP_ZOOM, Math.min(MAX_MAP_ZOOM, state.mapZoom));
  clampMapPan();
  content.style.transform = `translate3d(${state.mapPanX}px, ${state.mapPanY}px, 0) scale(${state.mapZoom})`;
  content.style.transition = state.mapGesture?.moved ? 'none' : 'transform .12s ease-out';
  updateMapZoomControls();
  saveState();
}
function updateCatalogueCount() {
  const count = state.locations.length;
  const positioned = state.locations.filter(place => Number.isFinite(place.x) && Number.isFinite(place.y)).length;
  const countEl = $('#catalogue-count');
  if (!countEl) return;
  countEl.textContent = count
    ? `${count.toLocaleString()} places · ${positioned.toLocaleString()} positioned`
    : 'No catalogue loaded';
}
function updateMapSettingsStatus() {
  const target = $('#map-data-status');
  if (!target) return;
  const mapLabel = state.mapImageLoaded
    ? (state.mapSource === 'bundled' ? 'Built-in YANIS v16 basemap is ready.' : 'A custom basemap image is loaded.')
    : 'No basemap image is loaded.';
  const catalogueLabel = state.locations.length
    ? `${state.locations.length.toLocaleString()} community locations are installed (${state.locations.filter(place => Number.isFinite(place.x) && Number.isFinite(place.y)).length.toLocaleString()} with positions).`
    : 'No location catalogue is installed.';
  target.textContent = `${mapLabel} ${catalogueLabel}`;
}

const GTADB_TYPE_LABELS = {
  hotel: 'Hotel', restaurant: 'Restaurant', retail: 'Retail', residential: 'Residential',
  transportation: 'Transport', infrastructure: 'Infrastructure', industrial: 'Industrial',
  government: 'Government', utilities: 'Utilities', natural: 'Natural area', agriculture: 'Agriculture',
  construction: 'Construction site', leisure: 'Leisure', events: 'Event venue', office: 'Office',
  service: 'Service', public: 'Public place', landmark: 'Landmark'
};
const GTADB_TYPE_PRIORITY = Object.keys(GTADB_TYPE_LABELS);
function primaryTypeTag(tags) {
  const values = Array.isArray(tags) ? tags.map(tag => String(tag).toLowerCase()) : [];
  return GTADB_TYPE_PRIORITY.find(tag => values.includes(tag)) || '';
}
function typeLabelFromTags(tags) {
  const key = primaryTypeTag(tags);
  return key ? GTADB_TYPE_LABELS[key] : 'Community place';
}
function categoryFromTags(tags) {
  const values = Array.isArray(tags) ? tags.map(tag => String(tag).toLowerCase()) : [];
  if (values.some(tag => ['natural', 'agriculture'].includes(tag))) return 'nature';
  if (values.some(tag => ['transportation', 'infrastructure', 'infr'].includes(tag) || /^#(bus|train|airport|metro|metromover|marina)$/.test(tag))) return 'transport';
  if (values.includes('residential')) return 'residential';
  if (values.some(tag => ['government', 'utilities', 'public'].includes(tag) || /^#(hospital|police|fire|school|government)$/.test(tag))) return 'civic';
  if (values.some(tag => ['leisure', 'events'].includes(tag))) return 'leisure';
  if (values.some(tag => ['hotel', 'restaurant', 'retail', 'service', 'office', 'industrial'].includes(tag))) return 'business';
  return 'landmark';
}
function displayTags(tags, mainType) {
  const values = Array.isArray(tags) ? tags : [];
  return [...new Set(values.map(raw => String(raw).trim()).filter(Boolean).filter(raw => !raw.startsWith('//'))
    .filter(raw => raw.toLowerCase() !== mainType)
    .map(raw => {
      if (/^l\d+$/i.test(raw)) return `Level ${raw.slice(1)}`;
      const cleaned = raw.replace(/^#/, '').replace(/[_-]+/g, ' ').trim();
      return cleaned.replace(/\b\w/g, letter => letter.toUpperCase());
    }))];
}
function mapMarkerScale(zoom) {
  // Keep the button's invisible hit-area the same screen size while shrinking
  // the visible dot as the map is magnified. The parent map scales by `zoom`.
  return 1 / Math.max(1, Number(zoom) || 1);
}
function mapMarkerVisualScale(zoom) {
  // One extra inverse square-root makes the visible pin get smaller with zoom.
  return 1 / Math.sqrt(Math.max(1, Number(zoom) || 1));
}
function renderMapPins(filter = '') {
  const mapRoot = $('#local-map');
  const markerRoot = $('#map-markers');
  const listRoot = $('#saved-places');
  const locationRoot = $('#location-results');
  if (!mapRoot || !markerRoot || !listRoot || !locationRoot) return;

  const query = filter.trim().toLocaleLowerCase();
  const visiblePins = state.pins.filter(pin =>
    !query || `${pin.name} ${pin.notes || ''}`.toLocaleLowerCase().includes(query)
  );
  const visibleLocations = state.locations.filter(place => {
    const categoryMatch = state.mapCategory === 'all' || place.category === state.mapCategory;
    const searchText = `${place.name} ${place.sourceAddress || ''} ${place.district || ''} ${place.region || ''} ${place.street || ''} ${place.area || ''} ${place.type || ''} ${place.category || ''} ${place.notes || ''} ${(place.tags || []).join(' ')}`.toLocaleLowerCase();
    return categoryMatch && (!query || searchText.includes(query));
  });

  // Avoid thousands of overlapping DOM markers: group nearby items into map-space clusters.
  const positioned = visibleLocations.filter(mapPlaceVisible);
  const cell = 3.5 / state.mapZoom;
  const buckets = new Map();
  positioned.forEach(place => {
    const key = `${Math.floor(place.x / cell)}:${Math.floor(place.y / cell)}`;
    if (!buckets.has(key)) buckets.set(key, []);
    buckets.get(key).push(place);
  });
  state.mapClusters = new Map();
  const markerHtml = [];
  const markerScale = mapMarkerScale(state.mapZoom).toFixed(3);
  const markerVisualScale = mapMarkerVisualScale(state.mapZoom).toFixed(3);
  visiblePins.forEach(pin => {
    markerHtml.push(`<button class="map-marker personal-marker" style="left:${Number(pin.x)}%;top:${Number(pin.y)}%;--marker-hit-scale:${markerScale};--marker-visual-scale:${markerVisualScale}" data-pin="${safeText(pin.id)}" aria-label="${safeText(pin.name)}"><span>★</span></button>`);
  });
  let clusterIndex = 0;
  for (const group of buckets.values()) {
    const x = group.reduce((sum, place) => sum + place.x, 0) / group.length;
    const y = group.reduce((sum, place) => sum + place.y, 0) / group.length;
    if (group.length === 1) {
      const place = group[0];
      markerHtml.push(`<button class="map-marker catalogue-marker" style="left:${x}%;top:${y}%;--marker-hit-scale:${markerScale};--marker-visual-scale:${markerVisualScale}" data-location="${safeText(place.id)}" aria-label="${safeText(place.name)}"><span>•</span></button>`);
    } else {
      state.mapClusters.set(String(clusterIndex), { places: group, x, y });
      const compactCluster = state.mapZoom >= 1.5 ? ' cluster-dot-only' : '';
      markerHtml.push(`<button class="map-marker catalogue-marker cluster-marker${compactCluster}" style="left:${x}%;top:${y}%;--marker-hit-scale:${markerScale};--marker-visual-scale:${markerVisualScale}" data-cluster-index="${clusterIndex}" aria-label="${group.length} grouped places"><span>${group.length > 99 ? '99+' : group.length}</span></button>`);
      clusterIndex += 1;
    }
  }
  markerRoot.innerHTML = markerHtml.join('');

  listRoot.innerHTML = visiblePins.length ? visiblePins.slice(0, 20).map(pin =>
    `<article class="saved-place"><span class="place-dot"></span><div class="place-copy"><strong>${safeText(pin.name)}</strong><small>${safeText(pin.notes || `Personal marker · ${Math.round(pin.x)}%, ${Math.round(pin.y)}%`)}</small></div><button data-remove-pin="${safeText(pin.id)}">Remove</button></article>`
  ).join('') : '';

  const listLimit = 60;
  const locationItems = visibleLocations.slice(0, listLimit);
  locationRoot.innerHTML = visibleLocations.length
    ? `<div class="location-list-heading"><strong>${state.catalogueCoordinateSystem === 'gtadb-v16' ? 'GTADB community places' : 'Imported locations'}</strong><small>${visibleLocations.length.toLocaleString()} found</small></div>` +
      locationItems.map(place => {
        const summary = [place.type || categoryLabel(place.category), place.area || [place.district, place.region].filter(Boolean).join(' · ') || place.region, place.street].filter(Boolean).join(' · ');
        return `<article class="saved-place catalogue-place"><span class="place-dot"></span><div class="place-copy"><strong>${safeText(place.name)}</strong><small>${safeText(summary || (mapPlaceVisible(place) ? `Map position ${Math.round(place.x)}%, ${Math.round(place.y)}%` : 'No mapped position'))}</small></div><button data-show-place="${safeText(place.id)}">${mapPlaceVisible(place) ? 'Details' : 'Details'}</button></article>`;
      }).join('') +
      (visibleLocations.length > listLimit ? `<p class="privacy-note">Showing ${listLimit} of ${visibleLocations.length.toLocaleString()} matches. Add more search terms to narrow it down.</p>` : '')
    : (state.locations.length && query ? '<p class="privacy-note">No imported locations match that search.</p>' : '');

  $$('[data-remove-pin]').forEach(button => button.addEventListener('click', () => {
    state.pins = state.pins.filter(pin => pin.id !== button.dataset.removePin);
    saveState(); renderMapPins($('#map-search').value); toast('Saved place removed from this phone.');
  }));
  $$('[data-pin]').forEach(button => button.addEventListener('click', () => {
    showPersonalPinDetails(button.dataset.pin);
  }));
  $$('[data-location]').forEach(button => button.addEventListener('click', () => {
    const place = state.locations.find(item => item.id === button.dataset.location);
    if (place) showPlaceDetails(place.id);
  }));
  $$('[data-show-place]').forEach(button => button.addEventListener('click', () => {
    const place = state.locations.find(item => item.id === button.dataset.showPlace);
    if (!place) return;
    showPlaceDetails(place.id);
    if (mapPlaceVisible(place)) focusMapPosition(place.x, place.y);
  }));
  $$('[data-cluster-index]').forEach(button => button.addEventListener('click', () => {
    const group = state.mapClusters.get(button.dataset.clusterIndex);
    if (!group) return;
    if (state.mapZoom < MAX_MAP_ZOOM - 0.05) {
      focusMapPosition(group.x, group.y, Math.min(MAX_MAP_ZOOM, state.mapZoom + 0.9));
      renderMapPins($('#map-search').value);
      toast(`Zoomed into ${group.places.length} nearby places.`);
    } else {
      showPlaceDetails(group.places[0].id);
      toast(`${group.places.length} locations are very close together. Search to choose another.`);
    }
  }));

  const notice = mapRoot.querySelector('.map-empty-notice');
  if (notice) {
    notice.style.display = state.mapImageLoaded ? 'none' : 'flex';
  }
  if (state.locations.length && state.catalogueCoordinateSystem === 'gtadb-v16' && !state.mapCompatible) {
    $('#map-calibration-note').hidden = false;
  } else {
    $('#map-calibration-note').hidden = true;
  }
  updateCatalogueCount();
  updateMapSettingsStatus();
  document.dispatchEvent(new CustomEvent('leonida:map-data-changed'));
}
function fitMapView() {
  state.mapZoom = 1;
  state.mapPanX = 0;
  state.mapPanY = 0;
  applyMapZoom();
  renderMapPins($('#map-search').value);
}
function focusMapPosition(x, y, zoom = Math.max(1.8, state.mapZoom)) {
  const content = $('#map-content');
  if (!content) return;
  const width = content.offsetWidth || $('#local-map').clientWidth;
  const height = content.offsetHeight || $('#local-map').clientHeight;
  state.mapZoom = zoom;
  state.mapPanX = -((x / 100) * width - width / 2) * zoom;
  state.mapPanY = -((y / 100) * height - height / 2) * zoom;
  applyMapZoom();
  renderMapPins($('#map-search').value);
}
function categoryLabel(category) {
  const labels = { landmark: 'Other place', nature: 'Nature', transport: 'Transport', business: 'Business', residential: 'Residential', civic: 'Civic / public', leisure: 'Leisure' };
  return labels[String(category || '').toLowerCase()] || 'Community place';
}
function showPlaceDetails(id) {
  const place = state.locations.find(item => item.id === id);
  if (!place) return;
  state.selectedPlaceId = id;
  const details = $('#place-details');
  const isGtadb = place.coordinateSystem === 'gtadb-v16';
  const nameKnown = !isGtadb || place.nameEvidence === 'KNOWN' || (place.confidence && place.confidence !== 'UNKNOWN' && place.nameEvidence !== 'UNKNOWN');
  const isPositioned = mapPlaceVisible(place);
  const area = place.area || [place.district, place.region].filter(Boolean).join(' · ') || place.areaReference || place.region || '';
  const positionLabel = isPositioned
    ? 'Approximate community map position'
    : (place.rawCoordinates ? 'Coordinates supplied but outside this map frame' : 'No map position supplied');
  const tagSignals = place.evidence?.tagSignals || {};
  const statusTags = [];
  if (tagSignals.unconfirmed || (place.tags || []).some(tag => String(tag).toLowerCase() === 'unconfirmed')) statusTags.push('Unconfirmed');
  if (tagSignals.demolished || (place.tags || []).some(tag => String(tag).toLowerCase() === 'demolished')) statusTags.push('Demolished');
  const attributes = [...new Set([...(place.tags || []), ...statusTags])].slice(0, 12);
  const facts = [
    ['Type', place.type || categoryLabel(place.category)],
    ...(place.street ? [['Street', place.street]] : []),
    ...(place.district ? [['District', place.district]] : []),
    ...(place.region ? [['Region', place.region]] : []),
    ...(!place.district && !place.region && place.areaReference ? [['Area reference', place.areaReference]] : []),
    ...(!place.street && !place.district && !place.region && !place.areaReference && area ? [['Area', area]] : []),
    ['Name confidence', nameKnown ? 'Listed in community source' : 'Unconfirmed / not identified'],
    ['Map position', positionLabel]
  ];
  const sourceCoordinates = place.rawCoordinates && place.rawCoordinates.every(Number.isFinite)
    ? place.rawCoordinates.map(value => Number(value).toFixed(1)).join(', ')
    : (isPositioned ? `${place.x.toFixed(1)}%, ${place.y.toFixed(1)}%` : 'Not available');
  details.hidden = false;
  details.innerHTML = `
    <div class="place-details-head">
      <div><span class="place-detail-kicker">${safeText(place.type || categoryLabel(place.category))} · ${safeText(place.id)}</span><h2>${safeText(place.name)}</h2></div>
      <button class="place-detail-close" id="close-place-details" aria-label="Close place details">×</button>
    </div>
    <p class="place-detail-intro">${nameKnown ? 'This place name is listed in the community catalogue.' : 'The community catalogue does not identify this place by name.'} Map placement is approximate and should be checked in-game.</p>
    <div class="place-detail-fields">
      ${facts.map(([label, value]) => `<div class="place-detail-field"><span>${safeText(label)}</span><strong>${safeText(value)}</strong></div>`).join('')}
    </div>
    ${attributes.length ? `<div class="place-detail-attributes"><span class="place-detail-section-label">Attributes</span><div class="place-tags">${attributes.map(tag => `<span>${safeText(tag)}</span>`).join('')}</div></div>` : ''}
    <details class="place-source-details">
      <summary>Source details &amp; confidence</summary>
      ${place.sourceAddress ? `<p><b>Original in-game catalogue label:</b> ${safeText(place.sourceAddress)}</p>` : ''}
      ${place.realWorldReference ? `<p><b>Contributor's real-world reference:</b> ${safeText(place.realWorldReference)}<br><small>This is a community reference used to identify the location, not an in-game street address or a Rockstar-verified fact.</small></p>` : ''}
      <p><b>Community map coordinates:</b> ${safeText(sourceCoordinates)}</p>
      ${place.notes ? `<p>${safeText(place.notes)}</p>` : ''}
      ${isGtadb ? `<p><b>Source record:</b> ${safeText(place.id)} · ${safeText(place.nameEvidence || 'Name unverified')} name · ${safeText(place.placementEvidence || 'Unknown')} placement</p>` : ''}
      <small>${safeText(place.source || GTADB_ATTRIBUTION)}</small>
    </details>
    <div class="place-detail-actions">
      ${isPositioned ? `<button id="focus-selected-place">Show on map</button>` : ''}
      ${isPositioned ? `<button id="save-selected-place">Save place</button>` : ''}
      ${isPositioned ? `<button id="add-selected-route-stop">Add to route</button>` : ''}
    </div>
  `;
  $('#close-place-details').addEventListener('click', () => { details.hidden = true; state.selectedPlaceId = null; });
  $('#save-selected-place')?.addEventListener('click', () => {
    if (!mapPlaceVisible(place)) { toast('This entry has no mapped position to save as a pin.'); return; }
    state.pins.unshift({
      id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
      name: place.name,
      notes: `${place.type || categoryLabel(place.category)} · ${area || 'Area not listed'} · Community location`,
      x: place.x, y: place.y, createdAt: new Date().toISOString()
    });
    saveState(); renderMapPins($('#map-search').value); toast('Place saved to your personal pins.');
  });
  $('#focus-selected-place')?.addEventListener('click', () => focusMapPosition(place.x, place.y));
  $('#add-selected-route-stop')?.addEventListener('click', () => {
    if (!window.LEONIDA_ROUTES) { toast('Route planner is still loading.'); return; }
    const result = window.LEONIDA_ROUTES.addPlace(place.id);
    toast(result.message);
  });
}
function showPersonalPinDetails(id) {
  const pin = state.pins.find(item => item.id === id);
  if (!pin) return;
  const details = $('#place-details');
  const created = pin.createdAt ? new Date(pin.createdAt) : null;
  const dateLabel = created && Number.isFinite(created.getTime())
    ? created.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : 'Not recorded';
  details.hidden = false;
  details.innerHTML = `
    <div class="place-details-head">
      <div><span class="place-detail-kicker">PERSONAL PIN</span><h2>${safeText(pin.name)}</h2></div>
      <button class="place-detail-close" id="close-place-details" aria-label="Close pin details">×</button>
    </div>
    <p class="place-detail-intro">${safeText(pin.notes || 'Your saved location on this phone.')}</p>
    <div class="place-detail-fields">
      <div class="place-detail-field"><span>Map position</span><strong>${Math.round(pin.x)}%, ${Math.round(pin.y)}%</strong></div>
      <div class="place-detail-field"><span>Saved</span><strong>${safeText(dateLabel)}</strong></div>
    </div>
    <div class="place-detail-actions"><button id="focus-personal-pin">Center on map</button><button id="delete-personal-pin" class="danger-detail-button">Delete pin</button></div>
  `;
  $('#close-place-details').addEventListener('click', () => { details.hidden = true; });
  $('#focus-personal-pin').addEventListener('click', () => focusMapPosition(pin.x, pin.y));
  $('#delete-personal-pin').addEventListener('click', () => {
    state.pins = state.pins.filter(item => item.id !== id);
    details.hidden = true;
    saveState(); renderMapPins($('#map-search').value); toast('Personal pin deleted.');
  });
}
function openPinDialog(x = 50, y = 50) {
  state.pendingPin = { x: Math.max(2, Math.min(98, x)), y: Math.max(2, Math.min(98, y)) };
  $('#pin-coordinate').textContent = `Map position · ${Math.round(state.pendingPin.x)}%, ${Math.round(state.pendingPin.y)}%`;
  $('#pin-name').value = ''; $('#pin-notes').value = '';
  $('#pin-dialog').showModal();
  setTimeout(() => $('#pin-name').focus(), 50);
}
function toCatalogueRecord(record, index, isNative) {
  if (!record || typeof record !== 'object') return null;
  const tags = Array.isArray(record.tags) ? record.tags.map(tag => String(tag).slice(0, 60)) : [];
  if (isNative) {
    if (typeof record.id !== 'string' || !/^L\d+$/.test(record.id)) return null;
    const rawAddress = String(record.inGameAddress || '').trim();
    const addressParts = rawAddress.split(',').map(part => part.trim()).filter(Boolean);
    const rawPlaceName = addressParts[0] || '';
    const unknownLabel = !rawPlaceName || /^(?:\?|unknown(?: name)?|unidentified)$/i.test(rawPlaceName);
    const mainTypeTag = primaryTypeTag(tags);
    const type = typeLabelFromTags(tags);
    // Keep partially identified names such as 'Parsons Hotel?' instead of
    // replacing the useful source text with an invented title.
    const name = unknownLabel ? 'Unidentified location' : rawPlaceName;
    const street = addressParts.length === 4 ? addressParts[1] : '';
    const district = addressParts.length === 4 ? addressParts[2] : (addressParts.length === 3 ? addressParts[1] : '');
    const region = addressParts.length >= 3 ? addressParts[addressParts.length - 1] : '';
    const areaReference = addressParts.length === 2 ? addressParts[1] : '';
    const area = [...new Set([district, region].filter(Boolean))].join(' · ') || areaReference;
    const realWorldReference = String(record.realWorldReference || '').trim().slice(0, 200);
    const coordinates = Array.isArray(record.inGameCoordinates) && record.inGameCoordinates.length >= 2
      ? [Number(record.inGameCoordinates[0]), Number(record.inGameCoordinates[1])]
      : null;
    const hasCoordinates = Boolean(coordinates && coordinates.every(Number.isFinite));
    const insideBounds = Boolean(hasCoordinates &&
      coordinates[0] >= GTADB_BOUNDS.west && coordinates[0] <= GTADB_BOUNDS.east &&
      coordinates[1] >= GTADB_BOUNDS.south && coordinates[1] <= GTADB_BOUNDS.north);
    const x = insideBounds ? ((coordinates[0] - GTADB_BOUNDS.west) / (GTADB_BOUNDS.east - GTADB_BOUNDS.west)) * 100 : null;
    const y = insideBounds ? ((GTADB_BOUNDS.north - coordinates[1]) / (GTADB_BOUNDS.north - GTADB_BOUNDS.south)) * 100 : null;
    const rawEvidence = record.evidence && typeof record.evidence === 'object' ? record.evidence : {};
    const tagSignals = rawEvidence.tagSignals && typeof rawEvidence.tagSignals === 'object' ? rawEvidence.tagSignals : {};
    const confidence = String(record.confidence || (unknownLabel ? 'UNKNOWN' : 'SUPPORTED')).toUpperCase();
    const nameEvidence = String(rawEvidence.name || (unknownLabel ? 'UNKNOWN' : 'KNOWN')).toUpperCase();
    const placementEvidence = String(rawEvidence.placement || (hasCoordinates ? 'APPROXIMATE' : 'UNKNOWN')).toUpperCase();
    const uncertaintyFlags = [];
    if (tagSignals.unconfirmed === true || tags.some(tag => String(tag).toLowerCase() === 'unconfirmed')) uncertaintyFlags.push('unconfirmed');
    if (tagSignals.demolished === true || tags.some(tag => String(tag).toLowerCase() === 'demolished')) uncertaintyFlags.push('demolished');
    if (Array.isArray(tagSignals.levelTags) && tagSignals.levelTags.length) {
      uncertaintyFlags.push(`level signals: ${tagSignals.levelTags.map(String).slice(0, 6).join(', ')}`);
    }
    const certainty = insideBounds ? 'Approximate community position' : (hasCoordinates ? 'Outside atlas frame' : 'No position supplied');
    const notes = [
      unknownLabel ? 'The source does not provide a confirmed place name.' : 'The place name is listed in the community source.',
      insideBounds ? 'The map position is a community reconstruction and is approximate, not an official Rockstar coordinate.' :
        hasCoordinates ? 'Coordinates are retained from the source but fall outside this atlas frame, so this record is not plotted.' :
          'The source does not provide map coordinates for this record.',
      uncertaintyFlags.length ? `Source flags: ${uncertaintyFlags.join('; ')}.` : ''
    ].filter(Boolean).join(' ');
    return {
      id: record.id,
      name,
      x, y,
      sourceAddress: rawAddress,
      realWorldReference,
      areaReference,
      rawCoordinates: hasCoordinates ? coordinates : null,
      street,
      district,
      region,
      area,
      category: categoryFromTags(tags),
      type,
      mainTypeTag,
      tags: displayTags(tags, mainTypeTag),
      notes,
      certainty,
      confidence,
      nameEvidence,
      placementEvidence,
      evidence: {
        confidence,
        name: nameEvidence,
        placement: placementEvidence,
        tagSignals: {
          levelTags: Array.isArray(tagSignals.levelTags) ? tagSignals.levelTags.map(String).slice(0, 20) : [],
          unconfirmed: tagSignals.unconfirmed === true,
          demolished: tagSignals.demolished === true
        }
      },
      coordinateSystem: 'gtadb-v16',
      source: `${GTADB_ATTRIBUTION} · revision ${GTADB_REVISION.slice(0, 7)}`
    };
  }

  const name = typeof record.name === 'string' ? record.name.trim() : '';
  if (!name) return null;
  const pos = record.position && typeof record.position === 'object' ? record.position : record;
  const x = Number(pos.x), y = Number(pos.y);
  const positioned = Number.isFinite(x) && Number.isFinite(y) && x >= 0 && x <= 100 && y >= 0 && y <= 100;
  return {
    id: String(record.id || `import-${index}-${name.slice(0, 40)}`),
    name: name.slice(0, 120),
    x: positioned ? x : null,
    y: positioned ? y : null,
    rawCoordinates: null,
    region: String(record.region || '').slice(0, 80),
    area: String(record.area || record.region || '').slice(0, 120),
    street: String(record.street || '').slice(0, 100),
    category: String(record.category || 'landmark').toLowerCase(),
    type: String(record.type || typeLabelFromTags(tags)),
    tags: displayTags(tags, primaryTypeTag(tags)),
    notes: String(record.notes || '').slice(0, 300),
    certainty: String(record.certainty || (positioned ? 'Imported position' : 'Unpositioned')).slice(0, 80),
    evidence: String(record.evidence || 'unverified'),
    coordinateSystem: 'percent',
    source: String(record.source || 'User-imported file').slice(0, 300)
  };
}
async function importLocationsText(text) {
  let parsed;
  try { parsed = JSON.parse(text); } catch { throw new Error('That file is not valid JSON.'); }
  const isNative = Boolean(parsed && typeof parsed === 'object' && Array.isArray(parsed.landmarks));
  const records = isNative ? parsed.landmarks :
    Array.isArray(parsed) ? parsed :
    (Array.isArray(parsed.locations) ? parsed.locations : parsed.places);
  if (!Array.isArray(records)) {
    throw new Error('Expected a GTADB snapshot with a "landmarks" array, or a JSON array / "locations" array.');
  }
  if (records.length > 10000) throw new Error('The file contains more than 10,000 records.');
  const imported = records.map((record, index) => toCatalogueRecord(record, index, isNative)).filter(Boolean);
  if (!imported.length) throw new Error('No valid named location records were found in that file.');
  if (isNative && imported.length < records.length * 0.85) {
    throw new Error('Too many GTADB rows did not match the expected record format. Nothing was imported.');
  }
  const merged = new Map(state.locations.map(item => [item.id, item]));
  imported.forEach(item => merged.set(item.id, item));
  const nextLocations = [...merged.values()];
  const nextSystem = isNative ? 'gtadb-v16' : 'percent';
  const sourceInfo = isNative && parsed.source && typeof parsed.source === 'object' ? parsed.source : {};
  const meta = isNative ? {
    source: String(sourceInfo.attribution || GTADB_ATTRIBUTION),
    repository: String(sourceInfo.repository || 'https://github.com/rolux/gtadb.org'),
    sourceUrl: String(sourceInfo.preferredSource || 'https://map.gtadb.org'),
    rawDataUrl: String(sourceInfo.rawUrl || GTADB_SOURCE_URL),
    license: String(sourceInfo.license || 'CC BY 4.0'),
    licenseUrl: String(sourceInfo.licenseUrl || 'https://creativecommons.org/licenses/by/4.0/'),
    revision: String(sourceInfo.revision || 'Unknown source revision'),
    sha256: String(sourceInfo.sha256 || ''),
    presentation: String(sourceInfo.presentation || 'Community reconstruction; approximate placement.'),
    counts: parsed.counts && typeof parsed.counts === 'object' ? parsed.counts : null,
    importedRecords: imported.length,
    catalogueSchema: 4,
    coordinateFrame: 'YANIS v16 / GTADB canonical bounds'
  } : {
    source: 'User-imported locations',
    license: 'User-supplied',
    importedRecords: imported.length
  };
  await persistCatalogue(nextLocations, meta, nextSystem);
  state.locations = nextLocations;
  state.catalogueMeta = meta;
  state.catalogueCoordinateSystem = nextSystem;
  if (isNative) state.mapCompatible = Boolean(window.LEONIDA_BUNDLED_MAP?.available);
  saveState();
  renderMapPins($('#map-search').value);
  return { count: imported.length, native: isNative };
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error || new Error('Could not read the map image.'));
    reader.readAsDataURL(blob);
  });
}
function dataUrlToBlob(dataUrl) {
  const match = /^data:(image\/(?:png|jpeg|webp|svg\+xml));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
  if (!match) throw new Error('The backup map image is not a supported image.');
  const binary = atob(match[2]);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], { type: match[1] });
}
async function displayMapBlob(blob) {
  const image = $('#map-image');
  if (mapObjectUrl) URL.revokeObjectURL(mapObjectUrl);
  if (!blob) {
    mapObjectUrl = null;
    image.removeAttribute('src');
    image.hidden = true;
    $('.map-art').style.display = 'block';
    if (window.LEONIDA_BUNDLED_MAP?.available) {
      image.src = './map-data/leonida-basemap.svg';
      image.hidden = false;
      $('.map-art').style.display = 'none';
      $('.map-empty-notice').style.display = 'none';
      state.mapImageLoaded = true;
      state.mapSource = 'bundled';
      // The bundled YANIS v16 map is the matching coordinate frame for the bundled GTADB catalogue.
      if (state.catalogueCoordinateSystem === 'gtadb-v16') state.mapCompatible = true;
      saveState();
    } else {
      $('.map-empty-notice').style.display = 'flex';
      state.mapImageLoaded = false;
      state.mapSource = 'none';
    }
    updateMapSettingsStatus();
    return;
  }
  mapObjectUrl = URL.createObjectURL(blob);
  image.src = mapObjectUrl;
  image.hidden = false;
  $('.map-empty-notice').style.display = 'none';
  $('.map-art').style.display = 'none';
  state.mapImageLoaded = true;
  state.mapSource = 'custom';
  updateMapSettingsStatus();
}
async function initialiseMapImage() {
  try {
    await displayMapBlob(await getMapBlob());
    renderMapPins($('#map-search').value);
  } catch (error) { toast(error.message); }
}
async function exportBackup() {
  const mapBlob = await getMapBlob().catch(() => null);
  const backup = {
    app: 'LEONIDA',
    version: 4,
    mapViewRevision: 4,
    exportedAt: new Date().toISOString(),
    plans: state.plans,
    pins: state.pins,
    locations: state.locations,
    catalogueMeta: state.catalogueMeta,
    catalogueCoordinateSystem: state.catalogueCoordinateSystem,
    mapCompatible: state.mapCompatible,
    mapPanX: state.mapPanX,
    mapPanY: state.mapPanY,
    mapZoom: state.mapZoom,
    finance: window.LEONIDA_FINANCE ? window.LEONIDA_FINANCE.exportData() : null,
    route: window.LEONIDA_ROUTES ? window.LEONIDA_ROUTES.exportData() : [],
    mapImageDataUrl: mapBlob ? await blobToDataUrl(mapBlob) : null
  };
  const content = JSON.stringify(backup);
  if (window.AndroidBridge && typeof window.AndroidBridge.saveTextFile === 'function') {
    window.AndroidBridge.saveTextFile('leonida-backup.json', content);
    toast('Choose where to save your LEONIDA backup.');
    return;
  }
  const blob = new Blob([content], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url; link.download = 'leonida-backup.json'; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  toast('Backup exported.');
}
async function restoreBackup(file) {
  if (!file || file.size > 30 * 1024 * 1024) throw new Error('Choose a backup file smaller than 30 MB.');
  const data = JSON.parse(await file.text());
  if (!data || data.app !== 'LEONIDA' || !Array.isArray(data.plans) || !Array.isArray(data.pins)) {
    throw new Error('This does not look like a LEONIDA backup.');
  }
  const restoredLocations = Array.isArray(data.locations) ? data.locations : [];
  const restoredSystem = data.catalogueCoordinateSystem || 'percent';
  const restoredMeta = data.catalogueMeta || null;
  const needsCatalogueUpgrade = restoredSystem === 'gtadb-v16' &&
    Boolean(window.LEONIDA_BUNDLED_GTADB && Array.isArray(window.LEONIDA_BUNDLED_GTADB.landmarks)) &&
    Number(restoredMeta?.catalogueSchema || 0) < 4;
  if (!needsCatalogueUpgrade) await persistCatalogue(restoredLocations, restoredMeta, restoredSystem);
  state.plans = data.plans;
  state.pins = data.pins;
  state.locations = restoredLocations;
  state.catalogueMeta = restoredMeta;
  state.catalogueCoordinateSystem = restoredSystem;
  state.mapCompatible = data.mapCompatible === true;
  // Restore old backups without bringing back the old GTADB detail schema.
  // importLocationsText replaces matching L-numbers and preserves extra user records.
  if (needsCatalogueUpgrade) {
    await importLocationsText(JSON.stringify(window.LEONIDA_BUNDLED_GTADB));
  }
  const restoredViewIsCurrent = data.mapViewRevision === 4;
  state.mapPanX = restoredViewIsCurrent && Number.isFinite(data.mapPanX) ? data.mapPanX : 0;
  state.mapPanY = restoredViewIsCurrent && Number.isFinite(data.mapPanY) ? data.mapPanY : 0;
  state.mapZoom = restoredViewIsCurrent && Number.isFinite(data.mapZoom) ? Math.max(MIN_MAP_ZOOM, Math.min(MAX_MAP_ZOOM, data.mapZoom)) : 1;
  if (data.finance && window.LEONIDA_FINANCE) window.LEONIDA_FINANCE.importData(data.finance);
  if (window.LEONIDA_ROUTES) window.LEONIDA_ROUTES.importData(Array.isArray(data.route) ? data.route : []);

  if (data.mapImageDataUrl) {
    const blob = dataUrlToBlob(data.mapImageDataUrl);
    if (blob.size > 8 * 1024 * 1024) throw new Error('The map image in this backup is larger than 8 MB.');
    await putMapBlob(blob);
    await displayMapBlob(blob);
  } else {
    await clearMapBlob().catch(() => {});
    await displayMapBlob(null);
  }
  saveState(); renderPlans(); renderProgress(); renderMapPins($('#map-search').value); applyMapZoom();
  toast('Backup restored on this phone.');
}

function addMessage(role, text) {
  const root = $('#chat-messages');
  const row = document.createElement('div');
  row.className = `message ${role === 'user' ? 'user-message' : 'assistant-message'}`;
  const avatar = document.createElement('div');
  avatar.className = role === 'user' ? 'avatar user-avatar' : 'avatar';
  avatar.textContent = role === 'user' ? 'YOU' : 'L';
  const wrap = document.createElement('div'); wrap.className = 'bubble-wrap';
  const sender = document.createElement('span');
  sender.className = 'sender'; sender.textContent = role === 'user' ? 'YOU' : 'LEONIDA';
  const bubble = document.createElement('div'); bubble.className = 'bubble'; bubble.textContent = text;
  wrap.append(sender, bubble); row.append(avatar, wrap); root.append(row); root.scrollTop = root.scrollHeight;
  if (role !== 'user' && window.LEONIDA_VOICE) window.LEONIDA_VOICE.speakReply(text);
}
function findPlaceMatches(query, limit = 8) {
  const normalized = String(query || '').trim().toLocaleLowerCase();
  if (!normalized) return [];
  const tokens = normalized.split(/\s+/).filter(Boolean);
  return state.locations.map(place => {
    const name = String(place.name || '').toLocaleLowerCase();
    const region = String(place.region || '').toLocaleLowerCase();
    const category = String(place.category || '').toLocaleLowerCase();
    const tags = (place.tags || []).join(' ').toLocaleLowerCase();
    const haystack = `${name} ${region} ${category} ${tags}`;
    let score = 0;
    if (name === normalized) score += 120;
    else if (name.startsWith(normalized)) score += 90;
    else if (name.includes(normalized)) score += 70;
    if (region.includes(normalized)) score += 35;
    if (category.includes(normalized) || tags.includes(normalized)) score += 20;
    const matchedTokens = tokens.filter(token => haystack.includes(token)).length;
    score += matchedTokens * 8;
    if (matchedTokens === tokens.length) score += 18;
    return { place, score };
  }).filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score || a.place.name.localeCompare(b.place.name))
    .slice(0, limit);
}

function setMapCategory(category) {
  const allowed = ['all', 'landmark', 'nature', 'transport', 'business', 'residential', 'civic', 'leisure'];
  const normalized = allowed.includes(category) ? category : 'all';
  state.mapCategory = normalized;
  $$('.map-filter').forEach(button => button.classList.toggle('active', button.dataset.category === normalized));
  renderMapPins($('#map-search').value);
  return normalized;
}

function runLocalTool(name, args = {}) {
  // These tools are deliberately local-only. A future cloud model may request
  // these named actions, but the handlers themselves continue to execute here.
  const handlers = {
    search_places: ({ query }) => {
      const value = String(query || '').trim();
      if (!value) return { ok: false, message: 'Tell me a place name or category to search for.' };
      switchScreen('map');
      $('#map-search').value = value;
      setMapCategory('all');
      renderMapPins(value);
      const matches = findPlaceMatches(value, 6);
      return {
        ok: true,
        count: matches.length,
        message: matches.length
          ? `Found ${matches.length}${matches.length === 6 ? '+' : ''} matching place${matches.length === 1 ? '' : 's'} for “${value}”. The filtered results are open on the Map tab.`
          : `I couldn't find “${value}” in the imported catalogue. Check the spelling or import the location data.`
      };
    },
    focus_place: ({ query }) => {
      const matches = findPlaceMatches(query, 10);
      switchScreen('map');
      if (!matches.length) return { ok: false, message: `I couldn't find a place matching “${query}”.` };
      if (matches.length > 1 &&
          matches[0].place.name !== matches[1].place.name &&
          matches[0].score === matches[1].score) {
        $('#map-search').value = query;
        renderMapPins(query);
        return {
          ok: true, ambiguous: true,
          message: `I found several possible matches for “${query}”. The filtered list is open below the map; choose the exact place.`
        };
      }
      const place = matches[0].place;
      $('#map-search').value = place.name;
      setMapCategory('all');
      renderMapPins(place.name);
      showPlaceDetails(place.id);
      if (mapPlaceVisible(place)) {
        focusMapPosition(place.x, place.y);
        return { ok: true, place, message: `Focused the map on ${place.name}. Its community placement is approximate; verify it in-game.` };
      }
      return {
        ok: true, place,
        message: `${place.name} is in your catalogue, but it has no position that can safely be plotted on the loaded basemap. Its details are open.`
      };
    },
    set_map_category: ({ category }) => {
      const aliases = {
        landmarks: 'landmark', landmark: 'landmark',
        nature: 'nature', natural: 'nature',
        transport: 'transport', transportation: 'transport',
        business: 'business', businesses: 'business',
        all: 'all'
      };
      const target = aliases[String(category || '').toLowerCase()];
      if (!target) return { ok: false, message: 'Available filters are all, landmarks, nature, transport, and businesses.' };
      switchScreen('map');
      $('#map-search').value = '';
      setMapCategory(target);
      const label = target === 'all' ? 'all categories' : `${target} places`;
      return { ok: true, message: `Showing ${label}.` };
    },
    zoom_map: ({ direction }) => {
      switchScreen('map');
      if (direction === 'in') state.mapZoom = Math.min(MAX_MAP_ZOOM, state.mapZoom + .5);
      else if (direction === 'out') state.mapZoom = Math.max(MIN_MAP_ZOOM, state.mapZoom - .5);
      else if (direction === 'reset') {
        fitMapView();
        return { ok: true, message: 'Map zoom reset to fitted view.' };
      } else return { ok: false, message: 'Use zoom in, zoom out, or reset zoom.' };
      applyMapZoom();
      renderMapPins($('#map-search').value);
      return { ok: true, message: `Map zoom ${direction} one step.` };
    },
    save_place: ({ query }) => {
      const match = findPlaceMatches(query, 1)[0];
      const place = match?.place;
      if (!place) return { ok: false, message: `I couldn't find “${query}” to save.` };
      if (!mapPlaceVisible(place)) return { ok: false, message: `${place.name} has no map position available to save as a pin.` };
      state.pins.unshift({
        id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
        name: place.name,
        notes: `Saved from catalogue · ${place.certainty || 'Community entry'}`,
        x: place.x, y: place.y, createdAt: new Date().toISOString()
      });
      saveState();
      switchScreen('map');
      renderMapPins($('#map-search').value);
      return { ok: true, message: `Saved ${place.name} to your personal map pins.` };
    },
    create_session_plan: ({ name, focus = 'Custom objectives', time = '30 minutes' }) => {
      const plan = makePlan({
        name: String(name || 'New session').slice(0, 60),
        focus: String(focus),
        time: String(time),
        notes: 'Created locally by the LEONIDA command interface.'
      });
      switchScreen('planner');
      return { ok: true, planId: plan.id, message: `Created “${plan.name}” and opened it in Planner.` };
    },
    get_progress: () => {
      switchScreen('progress');
      return {
        ok: true,
        plans: state.plans.length,
        completed: completedObjectives(),
        remaining: totalObjectives() - completedObjectives(),
        message: `${completedObjectives()} of ${totalObjectives()} objectives are complete across ${state.plans.length} saved plans.`
      };
    },
    show_plans: () => {
      switchScreen('planner');
      return { ok: true, count: state.plans.length, message: state.plans.length
        ? `You have ${state.plans.length} saved plans. The Planner tab is open.`
        : 'You do not have any saved plans yet.' };
    },
    show_map: () => {
      switchScreen('map');
      return { ok: true, message: 'Map workspace opened.' };
    }
  };

  const handler = handlers[name];
  if (!handler) return { ok: false, message: `Unknown local action: ${name}` };
  try {
    return handler(args);
  } catch (error) {
    return { ok: false, message: error instanceof Error ? error.message : 'That local action could not be completed.' };
  }
}

function parseLocalCommand(text) {
  const lower = text.trim().toLocaleLowerCase();

  if (/^(zoom in|zoom closer|increase map zoom)\b/.test(lower)) return runLocalTool('zoom_map', { direction: 'in' });
  if (/^(zoom out|zoom farther|decrease map zoom)\b/.test(lower)) return runLocalTool('zoom_map', { direction: 'out' });
  if (/^(reset zoom|reset map|fit map)\b/.test(lower)) return runLocalTool('zoom_map', { direction: 'reset' });

  const categoryMatch = lower.match(/^(?:show|filter|display|only)\s+(?:me\s+)?(?:only\s+)?(all|landmarks?|nature|natural places|transport(?:ation)?|business(?:es)?)\s*(?:places|locations|only)?[.!?]?$/);
  if (categoryMatch) {
    const phrase = categoryMatch[1];
    const category = /^landmarks?$/i.test(phrase) ? 'landmark' :
      /^business(?:es)?$/i.test(phrase) ? 'business' :
      /^transport(?:ation)?$/i.test(phrase) ? 'transport' :
      /^natural places$/i.test(phrase) ? 'nature' : phrase;
    return runLocalTool('set_map_category', { category });
  }

  if (/\b(progress|objectives?|tasks?)\b/.test(lower) && /\b(show|check|what|how|my)\b/.test(lower)) {
    return runLocalTool('get_progress');
  }
  if (/\b(plans?|sessions?)\b/.test(lower) && /\b(show|list|my|open)\b/.test(lower)) {
    return runLocalTool('show_plans');
  }
  if (/^(open|show)\s+(the\s+)?map[.!?]*$/.test(lower)) return runLocalTool('show_map');

  const saveMatch = text.match(/^(?:save|pin)\s+(?:the\s+place\s+)?(.+?)[.!?]*$/i);
  if (saveMatch && !/^this place$/i.test(saveMatch[1].trim())) {
    return runLocalTool('save_place', { query: saveMatch[1].trim() });
  }

  const planMatch = text.match(/^(?:create|make|build)\s+(?:a\s+)?(.{0,60}?)\s*(?:session\s+)?plan[.!?]*$/i);
  if (planMatch) {
    const details = planMatch[1].trim();
    const duration = text.match(/\b(15|30|45|60)\s*minutes?\b|\b(1|2)\s*hours?\b/i);
    const focus = /heist/i.test(lower) ? 'Heist preparation' :
      /collect/i.test(lower) ? 'Collectibles' :
      /explor/i.test(lower) ? 'Exploration' :
      /money/i.test(lower) ? 'Money run' : 'Custom objectives';
    const time = duration ? duration[0] : '30 minutes';
    const name = details.length > 0 ? text.replace(/[.!?]$/, '').slice(0, 60) : `${focus} session`;
    return runLocalTool('create_session_plan', { name, focus, time });
  }

  const searchMatch = text.match(/^(?:find|search for|locate|go to|zoom to|take me to|focus on|show me)\s+(.+?)[.!?]*$/i);
  if (searchMatch) return runLocalTool('focus_place', { query: searchMatch[1].trim() });

  if (/^(what can you do|help|capabilities)[.!?]*$/i.test(text)) {
    return {
      ok: true,
      message: 'Local commands: find or focus a place; filter nature, transport, businesses or landmarks; zoom the map; save a catalogue place as a pin; create a plan; show plans; or check progress. The cloud AI provider is not connected yet.'
    };
  }

  return null;
}

function respondToPrompt(raw) {
  const text = raw.trim();
  if (!text) return;
  addMessage('user', text);
  const result = parseLocalCommand(text);
  const answer = result
    ? result.message
    : 'I can execute local map, planner, and progress commands in this preview. Try “find airport”, “show nature”, “zoom in”, “save [place name]”, “create a 30-minute plan”, or “check progress”. The cloud AI model is not connected yet.';
  setTimeout(() => addMessage('assistant', answer), 120);
}

// Plan dialog
$('#plan-form').addEventListener('submit', event => {
  event.preventDefault();
  const plan = makePlan({
    name: $('#plan-name').value.trim(),
    focus: $('#plan-focus').value,
    time: $('#plan-time').value,
    notes: $('#plan-notes').value.trim()
  });
  $('#plan-dialog').close();
  switchScreen('planner');
  toast(`“${plan.name}” saved on this device.`);
});
$('#new-plan').addEventListener('click', openPlanDialog);

// Navigation and assistant
$$('.nav-item').forEach(button => button.addEventListener('click', () => switchScreen(button.dataset.screen)));
$('#chat-form').addEventListener('submit', event => {
  event.preventDefault();
  const value = $('#chat-input').value; $('#chat-input').value = '';
  respondToPrompt(value);
});
$('#chat-input').addEventListener('keydown', event => {
  if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); $('#chat-form').requestSubmit(); }
});
$$('[data-prompt]').forEach(button => button.addEventListener('click', () => {
  const prompt = button.dataset.prompt;
  if (state.screen !== 'assistant') switchScreen('assistant');
  respondToPrompt(prompt);
}));

// Map search, local pins, category filters, map image, and native catalogue import.
$('#map-search').addEventListener('input', event => renderMapPins(event.currentTarget.value));
$$('[data-category]').forEach(button => button.addEventListener('click', () => {
  state.mapCategory = button.dataset.category;
  $$('.map-filter').forEach(item => item.classList.toggle('active', item === button));
  renderMapPins($('#map-search').value);
}));
$('#add-map-pin').addEventListener('click', () => {
  state.pinPlacementMode = !state.pinPlacementMode;
  $('#pin-placement-banner').hidden = !state.pinPlacementMode;
  $('#local-map').classList.toggle('placing-pin', state.pinPlacementMode);
  $('#add-map-pin').classList.toggle('active', state.pinPlacementMode);
  $('#add-map-pin').querySelector('b').textContent = state.pinPlacementMode ? 'Tap map…' : 'Add pin';
  if (state.pinPlacementMode) toast('Tap the map where you want the personal pin.');
});
function cancelPinPlacement() {
  state.pinPlacementMode = false;
  $('#pin-placement-banner').hidden = true;
  $('#local-map').classList.remove('placing-pin');
  $('#add-map-pin').classList.remove('active');
  $('#add-map-pin').querySelector('b').textContent = 'Add pin';
}
$('#cancel-pin-placement').addEventListener('click', cancelPinPlacement);
$('#empty-map-settings').addEventListener('click', () => switchScreen('settings'));
$('#settings-button').addEventListener('click', () => switchScreen('settings'));
$('#settings-restore-map').addEventListener('click', async () => {
  try {
    await clearMapBlob();
    state.mapZoom = 1; state.mapPanX = 0; state.mapPanY = 0;
    if (window.LEONIDA_BUNDLED_MAP?.available) {
      state.mapCompatible = true;
      saveState();
      await displayMapBlob(null);
      renderMapPins($('#map-search').value);
      applyMapZoom();
      toast('Built-in community basemap restored.');
    } else {
      await displayMapBlob(null);
      toast('No bundled basemap is available in this build.');
    }
  } catch (error) { toast(error.message || 'Could not restore the built-in map.'); }
});
$('#settings-export-data').addEventListener('click', () => $('#export-data').click());
$('#settings-restore-data').addEventListener('click', () => $('#restore-data').click());
$('#settings-import-map').addEventListener('click', () => $('#map-image-input').click());
$('#map-image-input').addEventListener('change', async event => {
  const file = event.currentTarget.files?.[0];
  event.currentTarget.value = '';
  if (!file) return;
  const imageType = file.type || (file.name.toLowerCase().endsWith('.svg') ? 'image/svg+xml' : '');
  if (!['image/png', 'image/jpeg', 'image/webp', 'image/svg+xml'].includes(imageType) || file.size > 12 * 1024 * 1024) {
    toast('Choose a PNG, JPG, WebP, or SVG basemap smaller than 12 MB.');
    return;
  }
  try {
    await putMapBlob(file);
    await displayMapBlob(file);
    if (state.catalogueCoordinateSystem === 'gtadb-v16') {
      state.mapCompatible = confirm(
        'Does this image use the matching YANIS v16 / Leonida Atlas coordinate frame? Choose OK only for the corresponding community basemap. If unsure, choose Cancel.'
      );
    } else {
      state.mapCompatible = true;
    }
    state.mapZoom = 1; state.mapPanX = 0; state.mapPanY = 0;
    saveState(); applyMapZoom(); renderMapPins($('#map-search').value); updateMapSettingsStatus();
    toast(state.mapCompatible ? 'Basemap saved. Catalogue pins are enabled.' : 'Basemap saved. GTADB pins remain hidden until the matching basemap is loaded.');
  } catch (error) { toast(error.message || 'Could not save map image.'); }
});
$('#settings-import-locations').addEventListener('click', () => $('#locations-input').click());
$('#locations-input').addEventListener('change', async event => {
  const file = event.currentTarget.files?.[0];
  event.currentTarget.value = '';
  if (!file) return;
  if (file.size > 20 * 1024 * 1024) { toast('Choose a location JSON file smaller than 20 MB.'); return; }
  toast('Reading and validating catalogue…');
  try {
    const result = await importLocationsText(await file.text());
    updateMapSettingsStatus();
    toast(`${result.count.toLocaleString()} records imported${result.native ? ' from the GTADB snapshot' : ''}.`);
  } catch (error) { toast(error.message || 'Could not import locations.'); }
});
$('#map-zoom-in').addEventListener('click', () => { state.mapZoom = Math.min(MAX_MAP_ZOOM, state.mapZoom + .25); applyMapZoom(); renderMapPins($('#map-search').value); });
$('#map-zoom-out').addEventListener('click', () => { state.mapZoom = Math.max(MIN_MAP_ZOOM, state.mapZoom - .25); applyMapZoom(); renderMapPins($('#map-search').value); });
$('#map-zoom-reset').addEventListener('click', () => { state.mapZoom = 1; state.mapPanX = 0; state.mapPanY = 0; applyMapZoom(); renderMapPins($('#map-search').value); });

const localMap = $('#local-map');
const mapContent = $('#map-content');
function pointerDistance(a, b) { return Math.hypot(a.x - b.x, a.y - b.y); }
localMap.addEventListener('pointerdown', event => {
  if (event.target.closest('button')) return;
  try { localMap.setPointerCapture(event.pointerId); } catch {}
  state.mapPointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
  if (state.mapPointers.size === 1) {
    state.mapGesture = {
      kind: 'pan', startX: event.clientX, startY: event.clientY,
      panX: state.mapPanX, panY: state.mapPanY, moved: false,
      targetX: event.clientX, targetY: event.clientY
    };
  } else if (state.mapPointers.size === 2) {
    const [a, b] = [...state.mapPointers.values()];
    state.mapGesture = {
      kind: 'pinch', startDistance: pointerDistance(a, b),
      startZoom: state.mapZoom, moved: true
    };
  }
});
localMap.addEventListener('pointermove', event => {
  if (!state.mapPointers.has(event.pointerId)) return;
  state.mapPointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
  if (state.mapPointers.size >= 2 && state.mapGesture?.kind === 'pinch') {
    const [a, b] = [...state.mapPointers.values()];
    const startDistance = Math.max(1, state.mapGesture.startDistance);
    state.mapZoom = Math.max(MIN_MAP_ZOOM, Math.min(MAX_MAP_ZOOM, state.mapGesture.startZoom * pointerDistance(a, b) / startDistance));
    state.mapGesture.moved = true;
    mapClusterRefreshPending = true;
    applyMapZoom();
    return;
  }
  if (state.mapPointers.size === 1 && state.mapGesture?.kind === 'pan') {
    const dx = event.clientX - state.mapGesture.startX;
    const dy = event.clientY - state.mapGesture.startY;
    if (Math.abs(dx) + Math.abs(dy) > 7) state.mapGesture.moved = true;
    if (state.mapGesture.moved) {
      state.mapPanX = state.mapGesture.panX + dx;
      state.mapPanY = state.mapGesture.panY + dy;
      applyMapZoom();
    }
  }
});
function finishMapPointer(event, cancelled = false) {
  const gesture = state.mapGesture;
  const wasSingle = state.mapPointers.size === 1;
  const wasTap = wasSingle && gesture?.kind === 'pan' && !gesture.moved && !cancelled;
  state.mapPointers.delete(event.pointerId);
  if (wasTap && state.pinPlacementMode && !event.target.closest('button')) {
    const rect = mapContent.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width) * 100;
    const y = ((event.clientY - rect.top) / rect.height) * 100;
    cancelPinPlacement();
    if (x >= 0 && x <= 100 && y >= 0 && y <= 100) openPinDialog(x, y);
  }
  if (!state.mapPointers.size) {
    state.mapGesture = null;
    applyMapZoom();
    if (mapClusterRefreshPending) {
      mapClusterRefreshPending = false;
      renderMapPins($('#map-search').value);
    }
  } else if (state.mapPointers.size === 1) {
    const [remaining] = [...state.mapPointers.values()];
    state.mapGesture = {
      kind: 'pan', startX: remaining.x, startY: remaining.y,
      panX: state.mapPanX, panY: state.mapPanY, moved: true
    };
  }
}
localMap.addEventListener('pointerup', event => finishMapPointer(event));
localMap.addEventListener('pointercancel', event => finishMapPointer(event, true));
window.addEventListener('resize', () => applyMapZoom());
localMap.addEventListener('wheel', event => {
  event.preventDefault();
  state.mapZoom = Math.max(MIN_MAP_ZOOM, Math.min(MAX_MAP_ZOOM, state.mapZoom + (event.deltaY < 0 ? .15 : -.15)));
  applyMapZoom();
  renderMapPins($('#map-search').value);
}, { passive: false });

$('#pin-form').addEventListener('submit', event => {
  event.preventDefault();
  if (!state.pendingPin) return;
  state.pins.unshift({
    id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
    name: $('#pin-name').value.trim(),
    notes: $('#pin-notes').value.trim(),
    ...state.pendingPin,
    createdAt: new Date().toISOString()
  });
  state.pendingPin = null;
  $('#pin-dialog').close(); saveState(); renderMapPins($('#map-search').value);
  toast('Place saved locally on this phone.');
});
$('#pin-dialog').addEventListener('close', () => { state.pendingPin = null; });

// Backup export and restore
$('#export-data').addEventListener('click', () => exportBackup().catch(error => toast(error.message)));
$('#restore-data').addEventListener('click', () => $('#backup-input').click());
$('#backup-input').addEventListener('change', async event => {
  const file = event.currentTarget.files?.[0];
  event.currentTarget.value = '';
  if (!file) return;
  try { await restoreBackup(file); }
  catch (error) { toast(error.message || 'Could not restore this backup.'); }
});

window.addEventListener('online', updateNetwork);
window.addEventListener('offline', updateNetwork);
function updateNetwork() {
  $('#network-label').textContent = 'LOCAL ONLY';
  $('.offline-pill').classList.add('offline');
  $('.offline-pill').title = 'This build has no network permission.';
}


window.LEONIDA_MAP_API = {
  getPlace(id) {
    return state.locations.find(place => place.id === id) || null;
  },
  getPlaces() {
    return state.locations.slice();
  },
  isPlottable(placeOrId) {
    const place = typeof placeOrId === 'string' ? this.getPlace(placeOrId) : placeOrId;
    return Boolean(place && mapPlaceVisible(place));
  },
  showDetails(id) {
    showPlaceDetails(id);
  },
  focus(id) {
    const place = this.getPlace(id);
    if (!place || !mapPlaceVisible(place)) return false;
    switchScreen('map');
    focusMapPosition(place.x, place.y);
    return true;
  },
  notify() {
    document.dispatchEvent(new CustomEvent('leonida:map-data-changed'));
  }
};

loadState();
renderPlans();
renderProgress();
renderMapPins();
applyMapZoom();
updateNetwork();
initialiseCatalogueStorage();
initialiseMapImage();
if ('serviceWorker' in navigator && location.hostname !== 'appassets.androidplatform.net' && (location.protocol === 'https:' || location.hostname === 'localhost')) {
  navigator.serviceWorker.register('./sw.js').catch(error => console.warn('Service worker unavailable:', error));
}
